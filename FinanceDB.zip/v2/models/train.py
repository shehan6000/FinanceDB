"""
FinanceDB - Model Training Pipeline
Trains the neural compression model on financial time-series windows.

Author: FinanceDB Project
Module: 2 - Neural Compression Engine (Training)

Usage:
    python -m models.train
    python -m models.train --epochs 100 --batch-size 64
    python -m models.train --lr 0.0001 --patience 10
"""

import sys
import time
import pickle
from pathlib import Path
from typing import List, Dict, Tuple
from datetime import datetime

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import our compression model
from models.compression_model import CompressionModel, reconstruction_loss

# Import DataWindow for unpickling
from ingestion.windowing import DataWindow


class WindowDataset(Dataset):
    """
    PyTorch Dataset for loading DataWindow objects.
    """
    
    def __init__(self, window_dir: Path):
        """
        Initialize dataset by loading all windows from directory.
        
        Args:
            window_dir: Directory containing .pkl window files
        """
        self.window_dir = window_dir
        
        # Load all window files (excluding index.pkl)
        self.window_files = [
            f for f in window_dir.glob("*.pkl") 
            if f.name != "index.pkl"
        ]
        
        if len(self.window_files) == 0:
            raise ValueError(f"No window files found in {window_dir}")
        
        print(f"Found {len(self.window_files)} windows in {window_dir.name}")
    
    def __len__(self) -> int:
        return len(self.window_files)
    
    def __getitem__(self, idx: int) -> torch.Tensor:
        """
        Load and return a single window as tensor.
        
        Args:
            idx: Index of window to load
            
        Returns:
            Tensor of shape [seq_len, features] (e.g., [20, 20])
        """
        window_file = self.window_files[idx]
        
        # Load window object
        with open(window_file, 'rb') as f:
            window = pickle.load(f)
        
        # Extract features as tensor
        features = torch.FloatTensor(window.features)
        
        return features


class ModelTrainer:
    """
    Handles training, validation, and checkpointing of the compression model.
    """
    
    def __init__(
        self,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: DataLoader,
        device: str = 'cpu',
        learning_rate: float = 0.001,
        checkpoint_dir: str = "models/checkpoints"
    ):
        """
        Initialize trainer.
        
        Args:
            model: CompressionModel to train
            train_loader: DataLoader for training set
            val_loader: DataLoader for validation set
            device: Device to train on ('cpu' or 'cuda')
            learning_rate: Learning rate for optimizer
            checkpoint_dir: Directory to save model checkpoints
        """
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        
        # Optimizer
        self.optimizer = optim.Adam(model.parameters(), lr=learning_rate)
        
        # Checkpoint directory
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        # Training history
        self.history = {
            'train_loss': [],
            'val_loss': [],
            'epoch_times': [],
            'best_epoch': 0,
            'best_val_loss': float('inf')
        }
    
    def train_epoch(self) -> float:
        """
        Train for one epoch.
        
        Returns:
            Average training loss for the epoch
        """
        self.model.train()
        total_loss = 0.0
        num_batches = 0
        
        with tqdm(self.train_loader, desc="Training", leave=False) as pbar:
            for batch in pbar:
                # Move batch to device
                batch = batch.to(self.device)
                
                # Forward pass
                self.optimizer.zero_grad()
                reconstruction = self.model(batch)
                
                # Compute loss
                loss = reconstruction_loss(reconstruction, batch)
                
                # Backward pass
                loss.backward()
                self.optimizer.step()
                
                # Track statistics
                total_loss += loss.item()
                num_batches += 1
                
                # Update progress bar
                pbar.set_postfix({'loss': f'{loss.item():.6f}'})
        
        avg_loss = total_loss / num_batches
        return avg_loss
    
    def validate(self) -> float:
        """
        Validate the model on validation set.
        
        Returns:
            Average validation loss
        """
        self.model.eval()
        total_loss = 0.0
        num_batches = 0
        
        with torch.no_grad():
            with tqdm(self.val_loader, desc="Validating", leave=False) as pbar:
                for batch in pbar:
                    # Move batch to device
                    batch = batch.to(self.device)
                    
                    # Forward pass
                    reconstruction = self.model(batch)
                    
                    # Compute loss
                    loss = reconstruction_loss(reconstruction, batch)
                    
                    # Track statistics
                    total_loss += loss.item()
                    num_batches += 1
                    
                    # Update progress bar
                    pbar.set_postfix({'loss': f'{loss.item():.6f}'})
        
        avg_loss = total_loss / num_batches
        return avg_loss
    
    def save_checkpoint(self, epoch: int, val_loss: float, is_best: bool = False):
        """
        Save model checkpoint.
        
        Args:
            epoch: Current epoch number
            val_loss: Validation loss
            is_best: Whether this is the best model so far
        """
        checkpoint_path = self.checkpoint_dir / f"checkpoint_epoch_{epoch}.pt"
        
        self.model.save_checkpoint(
            str(checkpoint_path),
            optimizer=self.optimizer,
            epoch=epoch,
            loss=val_loss
        )
        
        # Save best model separately
        if is_best:
            best_path = self.checkpoint_dir / "best_model.pt"
            self.model.save_checkpoint(
                str(best_path),
                optimizer=self.optimizer,
                epoch=epoch,
                loss=val_loss
            )
            print(f"  → Saved best model (val_loss: {val_loss:.6f})")
    
    def train(
        self,
        num_epochs: int = 50,
        patience: int = 5,
        save_every: int = 10
    ) -> Dict:
        """
        Train the model with early stopping.
        
        Args:
            num_epochs: Maximum number of epochs
            patience: Early stopping patience
            save_every: Save checkpoint every N epochs
            
        Returns:
            Training history dictionary
        """
        print("\n" + "=" * 70)
        print("Starting Training")
        print("=" * 70)
        print(f"Device: {self.device}")
        print(f"Epochs: {num_epochs}")
        print(f"Batch size: {self.train_loader.batch_size}")
        print(f"Learning rate: {self.optimizer.param_groups[0]['lr']:.6f}")
        print(f"Early stopping patience: {patience}")
        print(f"Training samples: {len(self.train_loader.dataset)}")
        print(f"Validation samples: {len(self.val_loader.dataset)}")
        print("=" * 70 + "\n")
        
        epochs_without_improvement = 0
        
        for epoch in range(1, num_epochs + 1):
            epoch_start_time = time.time()
            
            # Train
            train_loss = self.train_epoch()
            
            # Validate
            val_loss = self.validate()
            
            # Track time
            epoch_time = time.time() - epoch_start_time
            
            # Update history
            self.history['train_loss'].append(train_loss)
            self.history['val_loss'].append(val_loss)
            self.history['epoch_times'].append(epoch_time)
            
            # Print progress
            print(f"Epoch {epoch:3d}/{num_epochs} | "
                  f"Train Loss: {train_loss:.6f} | "
                  f"Val Loss: {val_loss:.6f} | "
                  f"Time: {epoch_time:.2f}s")
            
            # Check for improvement
            is_best = val_loss < self.history['best_val_loss']
            if is_best:
                self.history['best_val_loss'] = val_loss
                self.history['best_epoch'] = epoch
                epochs_without_improvement = 0
            else:
                epochs_without_improvement += 1
            
            # Save checkpoint
            if epoch % save_every == 0 or is_best:
                self.save_checkpoint(epoch, val_loss, is_best=is_best)
            
            # Early stopping
            if epochs_without_improvement >= patience:
                print(f"\n⚠ Early stopping triggered after {epoch} epochs")
                print(f"  No improvement for {patience} consecutive epochs")
                break
        
        # Training complete
        print("\n" + "=" * 70)
        print("Training Complete")
        print("=" * 70)
        print(f"Best epoch: {self.history['best_epoch']}")
        print(f"Best validation loss: {self.history['best_val_loss']:.6f}")
        print(f"Total training time: {sum(self.history['epoch_times']):.2f}s")
        print(f"Average time per epoch: {np.mean(self.history['epoch_times']):.2f}s")
        print("=" * 70 + "\n")
        
        return self.history
    
    def plot_losses(self, save_path: str = "docs/training_curves.png"):
        """
        Plot training and validation loss curves.
        
        Args:
            save_path: Path to save the plot
        """
        # Create docs directory if needed
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Create figure
        plt.figure(figsize=(12, 5))
        
        # Plot 1: Loss curves
        plt.subplot(1, 2, 1)
        epochs = range(1, len(self.history['train_loss']) + 1)
        plt.plot(epochs, self.history['train_loss'], 'b-', label='Training Loss', linewidth=2)
        plt.plot(epochs, self.history['val_loss'], 'r-', label='Validation Loss', linewidth=2)
        plt.axvline(x=self.history['best_epoch'], color='g', linestyle='--', 
                   label=f'Best Epoch ({self.history["best_epoch"]})')
        plt.xlabel('Epoch', fontsize=12)
        plt.ylabel('MSE Loss', fontsize=12)
        plt.title('Training and Validation Loss', fontsize=14, fontweight='bold')
        plt.legend(fontsize=10)
        plt.grid(True, alpha=0.3)
        
        # Plot 2: Time per epoch
        plt.subplot(1, 2, 2)
        plt.plot(epochs, self.history['epoch_times'], 'g-', linewidth=2)
        plt.axhline(y=np.mean(self.history['epoch_times']), color='r', linestyle='--',
                   label=f'Average ({np.mean(self.history["epoch_times"]):.2f}s)')
        plt.xlabel('Epoch', fontsize=12)
        plt.ylabel('Time (seconds)', fontsize=12)
        plt.title('Training Time per Epoch', fontsize=14, fontweight='bold')
        plt.legend(fontsize=10)
        plt.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✓ Training curves saved to {save_path}")
        plt.close()


def calculate_compression_stats(model: CompressionModel) -> Dict:
    """
    Calculate compression statistics.
    
    Args:
        model: Trained compression model
        
    Returns:
        Dictionary with compression statistics
    """
    # Original window size
    seq_len = model.seq_len
    features = model.input_dim
    original_floats = seq_len * features
    original_bytes = original_floats * 4  # float32 = 4 bytes
    
    # Compressed size
    compressed_floats = model.embedding_dim
    compressed_bytes = compressed_floats * 4  # float32 = 4 bytes
    
    # Compression ratio
    ratio = original_bytes / compressed_bytes
    
    stats = {
        'original_shape': f"[{seq_len}, {features}]",
        'compressed_shape': f"[{compressed_floats}]",
        'original_floats': original_floats,
        'original_bytes': original_bytes,
        'compressed_floats': compressed_floats,
        'compressed_bytes': compressed_bytes,
        'compression_ratio': ratio,
        'space_savings_pct': (1 - 1/ratio) * 100
    }
    
    return stats


def main():
    """Main training script."""
    import argparse
    
    # Parse arguments
    parser = argparse.ArgumentParser(description="Train FinanceDB Compression Model")
    parser.add_argument('--epochs', type=int, default=50, help='Number of epochs')
    parser.add_argument('--batch-size', type=int, default=32, help='Batch size')
    parser.add_argument('--lr', type=float, default=0.001, help='Learning rate')
    parser.add_argument('--patience', type=int, default=5, help='Early stopping patience')
    parser.add_argument('--device', type=str, default='auto', help='Device (cpu/cuda/auto)')
    args = parser.parse_args()
    
    # Determine device
    if args.device == 'auto':
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    else:
        device = args.device
    
    print("\n" + "=" * 70)
    print("FinanceDB - Neural Compression Training")
    print("=" * 70)
    print(f"Configuration:")
    print(f"  Epochs: {args.epochs}")
    print(f"  Batch size: {args.batch_size}")
    print(f"  Learning rate: {args.lr}")
    print(f"  Early stopping patience: {args.patience}")
    print(f"  Device: {device}")
    print("=" * 70 + "\n")
    
    # Load datasets
    print("Loading datasets...")
    data_dir = Path("data/processed")
    
    train_dataset = WindowDataset(data_dir / "train")
    val_dataset = WindowDataset(data_dir / "val")
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=0  # Use 0 for Windows compatibility
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0
    )
    
    print(f"✓ Loaded {len(train_dataset)} training samples")
    print(f"✓ Loaded {len(val_dataset)} validation samples\n")
    
    # Create model
    print("Initializing model...")
    model = CompressionModel(
        input_dim=20,
        hidden_dim=128,
        embedding_dim=64,
        num_layers=2,
        seq_len=20
    )
    model.summary()
    
    # Calculate compression statistics
    print("\nCompression Statistics:")
    print("-" * 70)
    stats = calculate_compression_stats(model)
    print(f"Original size:      {stats['original_shape']} = {stats['original_floats']} floats = {stats['original_bytes']} bytes")
    print(f"Compressed size:    {stats['compressed_shape']} = {stats['compressed_floats']} floats = {stats['compressed_bytes']} bytes")
    print(f"Compression ratio:  {stats['compression_ratio']:.2f}x")
    print(f"Space savings:      {stats['space_savings_pct']:.1f}%")
    print("-" * 70 + "\n")
    
    # Initialize trainer
    trainer = ModelTrainer(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        device=device,
        learning_rate=args.lr,
        checkpoint_dir="models/checkpoints"
    )
    
    # Train
    try:
        history = trainer.train(
            num_epochs=args.epochs,
            patience=args.patience,
            save_every=10
        )
        
        # Plot results
        trainer.plot_losses("docs/training_curves.png")
        
        print("\n✓ Training completed successfully!")
        print(f"  Best model saved to: models/checkpoints/best_model.pt")
        print(f"  Training curves saved to: docs/training_curves.png")
        
    except KeyboardInterrupt:
        print("\n\n⚠ Training interrupted by user")
        sys.exit(1)
    
    except Exception as e:
        print(f"\n✗ Training failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()