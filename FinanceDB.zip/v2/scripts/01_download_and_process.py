#!/usr/bin/env python3
"""
FinanceDB - Data Download and Processing Pipeline
Orchestrates the complete data ingestion workflow from raw data to processed windows.

Usage:
    python scripts/01_download_and_process.py
    python scripts/01_download_and_process.py --symbols AAPL MSFT GOOGL
    python scripts/01_download_and_process.py --start-date 2020-01-01 --end-date 2024-01-01
    python scripts/01_download_and_process.py --force-redownload

Author: FinanceDB Project
"""

import sys
import argparse
from pathlib import Path
from datetime import datetime
from typing import List, Dict
import json

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from ingestion.data_loader import FinancialDataLoader
from ingestion.feature_extractor import FinancialFeatureExtractor
from ingestion.windowing import WindowGenerator, DataWindow

from loguru import logger
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.panel import Panel
from rich import print as rprint


# Initialize rich console for pretty output
console = Console()


class DataPipeline:
    """
    Orchestrates the complete data ingestion and processing pipeline.
    
    Pipeline Steps:
    1. Download OHLCV data from Yahoo Finance
    2. Extract technical features (20 indicators)
    3. Generate temporal windows (20-day sliding windows)
    4. Save processed windows to disk
    """
    
    def __init__(
        self,
        symbols: List[str],
        start_date: str,
        end_date: str,
        force_redownload: bool = False,
        window_size: int = 20,
        window_stride: int = 1,
        normalize_features: bool = True
    ):
        """
        Initialize data pipeline.
        
        Args:
            symbols: List of stock ticker symbols
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            force_redownload: Force re-download even if cached
            window_size: Number of timesteps per window
            window_stride: Stride for sliding windows
            normalize_features: Whether to normalize features
        """
        self.symbols = symbols
        self.start_date = start_date
        self.end_date = end_date
        self.force_redownload = force_redownload
        self.window_size = window_size
        self.window_stride = window_stride
        self.normalize_features = normalize_features
        
        # Initialize components
        self.data_loader = FinancialDataLoader(
            raw_data_dir="data/raw",
            start_date=start_date,
            end_date=end_date,
            cache_enabled=not force_redownload
        )
        
        self.feature_extractor = FinancialFeatureExtractor(
            normalize=normalize_features
        )
        
        self.window_generator = WindowGenerator(
            window_size=window_size,
            stride=window_stride,
            train_ratio=0.70,
            val_ratio=0.15,
            test_ratio=0.15,
            output_dir="data/processed"
        )
        
        # Statistics tracking
        self.stats = {
            'start_time': datetime.now(),
            'symbols_requested': len(symbols),
            'symbols_downloaded': 0,
            'symbols_failed': [],
            'features_extracted': 0,
            'windows_created': 0,
            'windows_saved': {'train': 0, 'val': 0, 'test': 0}
        }
        
        # Setup logging
        log_path = Path("data/logs")
        log_path.mkdir(parents=True, exist_ok=True)
        
        logger.add(
            log_path / f"pipeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log",
            rotation="10 MB",
            level="INFO"
        )
    
    def step1_download_data(self) -> Dict:
        """
        Step 1: Download stock data from Yahoo Finance.
        
        Returns:
            Dictionary mapping symbol -> OHLCV DataFrame
        """
        console.print("\n[bold cyan]Step 1/4: Downloading Stock Data[/bold cyan]")
        console.print(f"Symbols: {', '.join(self.symbols)}")
        console.print(f"Date range: {self.start_date} to {self.end_date}")
        console.print(f"Cache enabled: {not self.force_redownload}\n")
        
        try:
            # Download data
            ohlcv_data = self.data_loader.download_multiple(
                symbols=self.symbols,
                skip_existing=not self.force_redownload
            )
            
            # Update statistics
            self.stats['symbols_downloaded'] = len(ohlcv_data)
            self.stats['symbols_failed'] = [
                s for s in self.symbols if s not in ohlcv_data
            ]
            
            # Display results
            if ohlcv_data:
                console.print(f"✓ Successfully downloaded {len(ohlcv_data)} symbols", style="bold green")
            
            if self.stats['symbols_failed']:
                console.print(
                    f"✗ Failed to download {len(self.stats['symbols_failed'])} symbols: "
                    f"{', '.join(self.stats['symbols_failed'])}",
                    style="bold red"
                )
            
            return ohlcv_data
            
        except Exception as e:
            logger.error(f"Data download failed: {e}")
            console.print(f"✗ Data download failed: {e}", style="bold red")
            raise
    
    def step2_extract_features(self, ohlcv_data: Dict) -> Dict:
        """
        Step 2: Extract technical features from OHLCV data.
        
        Args:
            ohlcv_data: Dictionary mapping symbol -> OHLCV DataFrame
            
        Returns:
            Dictionary mapping symbol -> features DataFrame
        """
        console.print("\n[bold cyan]Step 2/4: Extracting Technical Features[/bold cyan]")
        console.print("Computing 20 technical indicators per symbol...\n")
        
        try:
            # Extract features
            features_data = self.feature_extractor.extract_features_batch(ohlcv_data)
            
            # Update statistics
            self.stats['features_extracted'] = len(features_data)
            
            # Display summary
            if features_data:
                sample_symbol = list(features_data.keys())[0]
                sample_features = features_data[sample_symbol]
                
                console.print(f"✓ Extracted features for {len(features_data)} symbols", style="bold green")
                console.print(f"  Features per symbol: {sample_features.shape[1]}")
                console.print(f"  Timesteps per symbol: ~{sample_features.shape[0]}")
                console.print(f"  Feature names: {', '.join(sample_features.columns[:5])}...")
            
            return features_data
            
        except Exception as e:
            logger.error(f"Feature extraction failed: {e}")
            console.print(f"✗ Feature extraction failed: {e}", style="bold red")
            raise
    
    def step3_generate_windows(
        self,
        features_data: Dict,
        ohlcv_data: Dict
    ) -> List[DataWindow]:
        """
        Step 3: Generate temporal windows from features.
        
        Args:
            features_data: Dictionary mapping symbol -> features DataFrame
            ohlcv_data: Dictionary mapping symbol -> OHLCV DataFrame (for metadata)
            
        Returns:
            List of DataWindow objects
        """
        console.print("\n[bold cyan]Step 3/4: Generating Temporal Windows[/bold cyan]")
        console.print(f"Window size: {self.window_size} days")
        console.print(f"Stride: {self.window_stride} day(s)")
        console.print(f"Split: 70% train / 15% val / 15% test\n")
        
        try:
            # Generate windows
            windows = self.window_generator.create_windows_batch(
                features_data,
                ohlcv_data
            )
            
            # Update statistics
            self.stats['windows_created'] = len(windows)
            
            # Display summary
            if windows:
                split_counts = {
                    'train': sum(w.split == 'train' for w in windows),
                    'val': sum(w.split == 'val' for w in windows),
                    'test': sum(w.split == 'test' for w in windows)
                }
                
                console.print(f"✓ Generated {len(windows)} windows", style="bold green")
                console.print(f"  Train: {split_counts['train']} ({split_counts['train']/len(windows)*100:.1f}%)")
                console.print(f"  Val: {split_counts['val']} ({split_counts['val']/len(windows)*100:.1f}%)")
                console.print(f"  Test: {split_counts['test']} ({split_counts['test']/len(windows)*100:.1f}%)")
            
            return windows
            
        except Exception as e:
            logger.error(f"Window generation failed: {e}")
            console.print(f"✗ Window generation failed: {e}", style="bold red")
            raise
    
    def step4_save_windows(self, windows: List[DataWindow]) -> Dict[str, int]:
        """
        Step 4: Save windows to disk.
        
        Args:
            windows: List of DataWindow objects
            
        Returns:
            Dictionary with counts per split
        """
        console.print("\n[bold cyan]Step 4/4: Saving Windows to Disk[/bold cyan]")
        console.print(f"Output directory: data/processed/\n")
        
        try:
            # Save windows
            counts = self.window_generator.save_windows(windows)
            
            # Update statistics
            self.stats['windows_saved'] = counts
            
            # Display summary
            total_saved = sum(counts.values())
            console.print(f"✓ Saved {total_saved} windows", style="bold green")
            console.print(f"  Train: {counts['train']} windows")
            console.print(f"  Val: {counts['val']} windows")
            console.print(f"  Test: {counts['test']} windows")
            
            return counts
            
        except Exception as e:
            logger.error(f"Window saving failed: {e}")
            console.print(f"✗ Window saving failed: {e}", style="bold red")
            raise
    
    def run(self) -> Dict:
        """
        Run the complete data pipeline.
        
        Returns:
            Dictionary with pipeline statistics
        """
        # Display header
        console.print(Panel.fit(
            "[bold yellow]FinanceDB Data Pipeline[/bold yellow]\n"
            "Download → Extract → Window → Save",
            border_style="cyan"
        ))
        
        try:
            # Step 1: Download data
            ohlcv_data = self.step1_download_data()
            
            if not ohlcv_data:
                console.print("\n✗ No data downloaded. Aborting pipeline.", style="bold red")
                return self.stats
            
            # Step 2: Extract features
            features_data = self.step2_extract_features(ohlcv_data)
            
            # Step 3: Generate windows
            windows = self.step3_generate_windows(features_data, ohlcv_data)
            
            if not windows:
                console.print("\n✗ No windows generated. Aborting pipeline.", style="bold red")
                return self.stats
            
            # Step 4: Save windows
            self.step4_save_windows(windows)
            
            # Compute final statistics
            self.stats['end_time'] = datetime.now()
            self.stats['duration_seconds'] = (
                self.stats['end_time'] - self.stats['start_time']
            ).total_seconds()
            
            # Get detailed window statistics
            window_stats = self.window_generator.get_statistics(windows)
            self.stats['window_stats'] = window_stats
            
            # Display summary
            self._display_summary()
            
            # Save statistics to file
            self._save_statistics()
            
            console.print("\n✓ Pipeline completed successfully!", style="bold green")
            
            return self.stats
            
        except Exception as e:
            logger.error(f"Pipeline failed: {e}")
            console.print(f"\n✗ Pipeline failed: {e}", style="bold red")
            raise
    
    def _display_summary(self):
        """Display final pipeline summary."""
        console.print("\n" + "=" * 70)
        console.print("[bold yellow]PIPELINE SUMMARY[/bold yellow]")
        console.print("=" * 70)
        
        # Create summary table
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Metric", style="dim")
        table.add_column("Value", justify="right")
        
        # Add rows
        table.add_row("Symbols Requested", str(self.stats['symbols_requested']))
        table.add_row("Symbols Downloaded", str(self.stats['symbols_downloaded']))
        table.add_row("Symbols Failed", str(len(self.stats['symbols_failed'])))
        table.add_row("", "")
        table.add_row("Features Extracted", str(self.stats['features_extracted']))
        table.add_row("Feature Count", "20")
        table.add_row("", "")
        table.add_row("Windows Created", str(self.stats['windows_created']))
        table.add_row("  ├─ Train", str(self.stats['windows_saved']['train']))
        table.add_row("  ├─ Val", str(self.stats['windows_saved']['val']))
        table.add_row("  └─ Test", str(self.stats['windows_saved']['test']))
        table.add_row("", "")
        table.add_row("Window Size", f"{self.window_size} timesteps")
        table.add_row("Window Stride", f"{self.window_stride} day(s)")
        table.add_row("", "")
        
        if 'window_stats' in self.stats:
            ws = self.stats['window_stats']
            table.add_row("Date Range", f"{ws['date_range']['start']} to {ws['date_range']['end']}")
            table.add_row("Span", f"{ws['date_range']['span_days']} days")
            table.add_row("Memory Usage", f"{ws['total_memory_mb']:.2f} MB")
        
        table.add_row("", "")
        table.add_row("Duration", f"{self.stats['duration_seconds']:.1f} seconds")
        
        console.print(table)
        
        # Failed symbols
        if self.stats['symbols_failed']:
            console.print(f"\n[bold red]Failed Symbols:[/bold red] {', '.join(self.stats['symbols_failed'])}")
    
    def _save_statistics(self):
        """Save pipeline statistics to JSON file."""
        stats_path = Path("data/processed/pipeline_stats.json")
        
        # Convert datetime objects to strings
        stats_serializable = {
            k: (v.isoformat() if isinstance(v, datetime) else v)
            for k, v in self.stats.items()
        }
        
        with open(stats_path, 'w') as f:
            json.dump(stats_serializable, f, indent=2, default=str)
        
        logger.info(f"Saved pipeline statistics to {stats_path}")


def parse_arguments() -> argparse.Namespace:
    """Parse command line arguments."""
    # Default symbols (25 S&P 500 stocks)
    default_symbols = [
        'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NVDA', 'META', 'TSLA',
        'JPM', 'V', 'MA', 'BAC', 'WFC',
        'JNJ', 'UNH', 'PFE', 'ABBV',
        'WMT', 'HD', 'DIS', 'NKE',
        'BA', 'CAT', 'GE',
        'XOM', 'CVX'
    ]
    
    parser = argparse.ArgumentParser(
        description="FinanceDB Data Download and Processing Pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Use default symbols (25 S&P 500 stocks)
  python scripts/01_download_and_process.py
  
  # Specify custom symbols
  python scripts/01_download_and_process.py --symbols AAPL MSFT GOOGL
  
  # Custom date range
  python scripts/01_download_and_process.py --start-date 2020-01-01 --end-date 2023-12-31
  
  # Force re-download (ignore cache)
  python scripts/01_download_and_process.py --force-redownload
  
  # Larger windows with no overlap
  python scripts/01_download_and_process.py --window-size 60 --window-stride 60
        """
    )
    
    parser.add_argument(
        '--symbols',
        nargs='+',
        default=default_symbols,
        help='List of stock ticker symbols (default: 25 S&P 500 stocks)'
    )
    
    parser.add_argument(
        '--start-date',
        type=str,
        default='2020-01-01',
        help='Start date for historical data (YYYY-MM-DD, default: 2020-01-01)'
    )
    
    parser.add_argument(
        '--end-date',
        type=str,
        default='2024-01-01',
        help='End date for historical data (YYYY-MM-DD, default: 2024-01-01)'
    )
    
    parser.add_argument(
        '--force-redownload',
        action='store_true',
        help='Force re-download even if data is cached'
    )
    
    parser.add_argument(
        '--window-size',
        type=int,
        default=20,
        help='Number of timesteps per window (default: 20)'
    )
    
    parser.add_argument(
        '--window-stride',
        type=int,
        default=1,
        help='Stride for sliding windows (default: 1)'
    )
    
    parser.add_argument(
        '--no-normalize',
        action='store_true',
        help='Disable feature normalization'
    )
    
    return parser.parse_args()


def main():
    """Main entry point."""
    # Parse arguments
    args = parse_arguments()
    
    # Display configuration
    console.print("\n[bold]Configuration:[/bold]")
    console.print(f"  Symbols: {len(args.symbols)} stocks")
    console.print(f"  Date range: {args.start_date} to {args.end_date}")
    console.print(f"  Force redownload: {args.force_redownload}")
    console.print(f"  Window size: {args.window_size}")
    console.print(f"  Window stride: {args.window_stride}")
    console.print(f"  Normalize features: {not args.no_normalize}")
    
    # Initialize pipeline
    pipeline = DataPipeline(
        symbols=args.symbols,
        start_date=args.start_date,
        end_date=args.end_date,
        force_redownload=args.force_redownload,
        window_size=args.window_size,
        window_stride=args.window_stride,
        normalize_features=not args.no_normalize
    )
    
    # Run pipeline
    try:
        stats = pipeline.run()
        
        # Exit with success
        sys.exit(0)
        
    except KeyboardInterrupt:
        console.print("\n\n✗ Pipeline interrupted by user", style="bold red")
        sys.exit(1)
        
    except Exception as e:
        console.print(f"\n✗ Pipeline failed with error: {e}", style="bold red")
        logger.exception("Pipeline failed")
        sys.exit(1)


if __name__ == "__main__":
    main()
