"""
FinanceDB - Financial Data Loader Module
Downloads stock market data from Yahoo Finance API for database ingestion.

Author: FinanceDB Project
Module: 1 - Data Ingestion
"""

import os
import pickle
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional
import warnings

import yfinance as yf
import pandas as pd
from tqdm import tqdm
from loguru import logger

# Suppress yfinance warnings
warnings.filterwarnings('ignore')


class FinancialDataLoader:
    """
    Downloads and caches financial market data from Yahoo Finance.
    
    Features:
    - Multi-symbol batch downloading
    - Automatic caching to avoid redundant downloads
    - Graceful error handling for failed symbols
    - Progress tracking with tqdm
    - Data validation and quality checks
    """
    
    # Extended list of 25 S&P 500 stocks across various sectors
    DEFAULT_SYMBOLS = [
        # Technology
        'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NVDA', 'META', 'TSLA',
        # Financial
        'JPM', 'V', 'MA', 'BAC', 'WFC',
        # Healthcare
        'JNJ', 'UNH', 'PFE', 'ABBV',
        # Consumer
        'WMT', 'HD', 'DIS', 'NKE',
        # Industrial
        'BA', 'CAT', 'GE',
        # Energy
        'XOM', 'CVX'
    ]
    
    def __init__(
        self,
        raw_data_dir: str = "data/raw",
        start_date: str = "2020-01-01",
        end_date: str = "2024-01-01",
        cache_enabled: bool = True
    ):
        """
        Initialize the Financial Data Loader.
        
        Args:
            raw_data_dir: Directory to save raw downloaded data
            start_date: Start date for historical data (YYYY-MM-DD)
            end_date: End date for historical data (YYYY-MM-DD)
            cache_enabled: If True, skip re-downloading existing data
        """
        self.raw_data_dir = Path(raw_data_dir)
        self.start_date = start_date
        self.end_date = end_date
        self.cache_enabled = cache_enabled
        
        # Create directory structure
        self.raw_data_dir.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        logger.add(
            self.raw_data_dir.parent / "logs" / "data_loader.log",
            rotation="10 MB",
            level="INFO"
        )
        
        logger.info(f"Initialized FinancialDataLoader")
        logger.info(f"Data directory: {self.raw_data_dir.absolute()}")
        logger.info(f"Date range: {start_date} to {end_date}")
    
    def _get_cache_path(self, symbol: str) -> Path:
        """Get the cache file path for a symbol."""
        return self.raw_data_dir / f"{symbol}_{self.start_date}_{self.end_date}.pkl"
    
    def _is_cached(self, symbol: str) -> bool:
        """Check if data for symbol is already cached."""
        cache_path = self._get_cache_path(symbol)
        return cache_path.exists() if self.cache_enabled else False
    
    def _load_from_cache(self, symbol: str) -> Optional[pd.DataFrame]:
        """Load cached data for a symbol."""
        cache_path = self._get_cache_path(symbol)
        try:
            with open(cache_path, 'rb') as f:
                data = pickle.load(f)
            logger.debug(f"Loaded {symbol} from cache")
            return data
        except Exception as e:
            logger.warning(f"Failed to load cache for {symbol}: {e}")
            return None
    
    def _save_to_cache(self, symbol: str, data: pd.DataFrame) -> None:
        """Save data to cache."""
        cache_path = self._get_cache_path(symbol)
        try:
            with open(cache_path, 'wb') as f:
                pickle.dump(data, f, protocol=pickle.HIGHEST_PROTOCOL)
            logger.debug(f"Saved {symbol} to cache")
        except Exception as e:
            logger.warning(f"Failed to save cache for {symbol}: {e}")
    
    def _validate_data(self, symbol: str, data: pd.DataFrame) -> bool:
        """
        Validate downloaded data quality.
        
        Args:
            symbol: Stock symbol
            data: Downloaded dataframe
            
        Returns:
            True if data passes validation, False otherwise
        """
        if data is None or data.empty:
            logger.warning(f"{symbol}: No data returned")
            return False
        
        # Check for required columns
        required_cols = ['Open', 'High', 'Low', 'Close', 'Volume']
        missing_cols = [col for col in required_cols if col not in data.columns]
        if missing_cols:
            logger.warning(f"{symbol}: Missing columns {missing_cols}")
            return False
        
        # Check for minimum data points (at least 6 months of trading days ~120 days)
        if len(data) < 120:
            logger.warning(f"{symbol}: Insufficient data ({len(data)} rows)")
            return False
        
        # Check for excessive missing values
        null_pct = (data[required_cols].isnull().sum() / len(data) * 100)
        if null_pct.max() > 5:  # More than 5% missing
            logger.warning(f"{symbol}: Excessive missing values: {null_pct.to_dict()}")
            return False
        
        # Check for data anomalies (negative prices/volumes)
        if (data[['Open', 'High', 'Low', 'Close']] <= 0).any().any():
            logger.warning(f"{symbol}: Invalid negative prices detected")
            return False
        
        if (data['Volume'] < 0).any():
            logger.warning(f"{symbol}: Invalid negative volumes detected")
            return False
        
        logger.debug(f"{symbol}: Data validation passed ({len(data)} rows)")
        return True
    
    def download_symbol(self, symbol: str) -> Optional[pd.DataFrame]:
        """
        Download data for a single symbol.
        
        Args:
            symbol: Stock ticker symbol (e.g., 'AAPL')
            
        Returns:
            DataFrame with OHLCV data, or None if download failed
        """
        # Check cache first
        if self._is_cached(symbol):
            data = self._load_from_cache(symbol)
            if data is not None and self._validate_data(symbol, data):
                return data
            else:
                logger.info(f"{symbol}: Cache invalid, re-downloading")
        
        # Download from Yahoo Finance
        try:
            logger.info(f"{symbol}: Downloading from Yahoo Finance...")
            ticker = yf.Ticker(symbol)
            data = ticker.history(
                start=self.start_date,
                end=self.end_date,
                auto_adjust=True,  # Adjust for splits and dividends
                actions=False  # Don't include dividend/split actions
            )
            
            # Validate data
            if not self._validate_data(symbol, data):
                return None
            
            # Add metadata
            data.attrs['symbol'] = symbol
            data.attrs['download_date'] = datetime.now().isoformat()
            data.attrs['start_date'] = self.start_date
            data.attrs['end_date'] = self.end_date
            
            # Save to cache
            self._save_to_cache(symbol, data)
            
            logger.info(f"{symbol}: Successfully downloaded {len(data)} rows")
            return data
            
        except Exception as e:
            logger.error(f"{symbol}: Download failed - {str(e)}")
            return None
    
    def download_multiple(
        self,
        symbols: Optional[List[str]] = None,
        skip_existing: bool = True
    ) -> Dict[str, pd.DataFrame]:
        """
        Download data for multiple symbols with progress tracking.
        
        Args:
            symbols: List of ticker symbols. If None, uses DEFAULT_SYMBOLS
            skip_existing: If True, skip symbols that are already cached
            
        Returns:
            Dictionary mapping symbols to their DataFrames
        """
        if symbols is None:
            symbols = self.DEFAULT_SYMBOLS
        
        logger.info(f"Starting batch download for {len(symbols)} symbols")
        
        # Filter out cached symbols if requested
        if skip_existing and self.cache_enabled:
            original_count = len(symbols)
            symbols = [s for s in symbols if not self._is_cached(s)]
            skipped = original_count - len(symbols)
            if skipped > 0:
                logger.info(f"Skipping {skipped} cached symbols")
        
        # Download with progress bar
        results = {}
        failed_symbols = []
        
        with tqdm(symbols, desc="Downloading stocks", unit="symbol") as pbar:
            for symbol in pbar:
                pbar.set_postfix_str(f"Current: {symbol}")
                data = self.download_symbol(symbol)
                
                if data is not None:
                    results[symbol] = data
                else:
                    failed_symbols.append(symbol)
        
        # Summary
        logger.info(f"\n{'='*60}")
        logger.info(f"Download Summary:")
        logger.info(f"  Total symbols: {len(symbols)}")
        logger.info(f"  Successful: {len(results)}")
        logger.info(f"  Failed: {len(failed_symbols)}")
        if failed_symbols:
            logger.info(f"  Failed symbols: {', '.join(failed_symbols)}")
        logger.info(f"{'='*60}\n")
        
        return results
    
    def get_data_summary(self) -> pd.DataFrame:
        """
        Generate a summary of all cached data.
        
        Returns:
            DataFrame with statistics for each cached symbol
        """
        cache_files = list(self.raw_data_dir.glob("*.pkl"))
        
        if not cache_files:
            logger.warning("No cached data found")
            return pd.DataFrame()
        
        summaries = []
        for cache_file in cache_files:
            try:
                with open(cache_file, 'rb') as f:
                    data = pickle.load(f)
                
                symbol = data.attrs.get('symbol', 'UNKNOWN')
                summaries.append({
                    'Symbol': symbol,
                    'Rows': len(data),
                    'Start Date': data.index.min().strftime('%Y-%m-%d'),
                    'End Date': data.index.max().strftime('%Y-%m-%d'),
                    'Avg Volume': f"{data['Volume'].mean():,.0f}",
                    'Price Range': f"${data['Low'].min():.2f} - ${data['High'].max():.2f}",
                    'File Size': f"{cache_file.stat().st_size / 1024:.1f} KB"
                })
            except Exception as e:
                logger.warning(f"Failed to read {cache_file}: {e}")
        
        return pd.DataFrame(summaries).sort_values('Symbol')


def main():
    """Main entry point for command-line execution."""
    print("=" * 60)
    print("FinanceDB - Data Loader")
    print("=" * 60)
    print()
    
    # Initialize loader
    loader = FinancialDataLoader(
        raw_data_dir="data/raw",
        start_date="2020-01-01",
        end_date="2024-01-01",
        cache_enabled=True
    )
    
    # Download data
    print(f"Downloading {len(loader.DEFAULT_SYMBOLS)} S&P 500 stocks...")
    print(f"Date range: 2020-01-01 to 2024-01-01")
    print()
    
    results = loader.download_multiple()
    
    # Display summary
    print("\nData Summary:")
    print("-" * 60)
    summary_df = loader.get_data_summary()
    if not summary_df.empty:
        print(summary_df.to_string(index=False))
    print()
    
    # Save summary to CSV
    summary_path = Path("data/raw") / "download_summary.csv"
    summary_df.to_csv(summary_path, index=False)
    print(f"Summary saved to: {summary_path}")
    print()
    print("✓ Data download complete!")


if __name__ == "__main__":
    main()
