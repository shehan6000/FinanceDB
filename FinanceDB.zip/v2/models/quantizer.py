"""
FinanceDB - Embedding Quantization Module
Quantizes float32 embeddings to uint8 for 4x additional compression.

Author: FinanceDB Project
Module: 2 - Neural Compression Engine (Quantization)

Usage:
    python -m models.quantizer
"""

import sys
import pickle
import json
from pathlib import Path
from typing import Tuple, Optional

import numpy as np
import torch
from tqdm import tqdm

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.compression_model import CompressionModel
from ingestion.windowing import DataWindow


class EmbeddingQuantizer:
    """
    Quantizes float32 embeddings to uint8 for additional compression.
    
    Compression breakdown:
    - Original window: [20, 20] float32 = 1,600 bytes
    - Neural embedding: [64] float32 = 256 bytes (6.25x)
    - Quantized embedding: [64] uint8 = 64 bytes (25x total)
    
    Quantization formula:
    - Quantize:   uint8 = ((float32 - min) / (max - min)) * 255
    - Dequantize: float32 = (uint8 / 255) * (max - min) + min
    """
    
    def __init__(self, embedding_dim: int = 64):
        """
        Initialize quantizer.
        
        Args:
            embedding_dim: Dimension of embeddings (64)
        """
        self.embedding_dim = embedding_dim
        
        # Quantization parameters (learned from training data)
        self.min_vals = None  # [embedding_dim] - min value per dimension
        self.max_vals = None  # [embedding_dim] - max value per dimension
        self.is_fitted = False
    
    def fit(self, embeddings: np.ndarray):
        """
        Learn quantization parameters from embeddings.
        
        Args:
            embeddings: Array of shape [num_samples, embedding_dim]
                       Float32 embeddings from training set
        """
        if embeddings.ndim != 2:
            raise ValueError(f"Expected 2D array, got shape {embeddings.shape}")
        
        if embeddings.shape[1] != self.embedding_dim:
            raise ValueError(
                f"Expected embedding_dim={self.embedding_dim}, "
                f"got {embeddings.shape[1]}"
            )
        
        # Compute min and max per dimension
        self.min_vals = np.min(embeddings, axis=0)
        self.max_vals = np.max(embeddings, axis=0)
        
        # Handle constant dimensions (min == max)
        constant_dims = self.min_vals == self.max_vals
        if constant_dims.any():
            # Add small epsilon to avoid division by zero
            self.max_vals[constant_dims] = self.min_vals[constant_dims] + 1e-6
        
        self.is_fitted = True
        
        print(f"✓ Quantizer fitted on {embeddings.shape[0]} embeddings")
        print(f"  Min range: [{self.min_vals.min():.6f}, {self.min_vals.max():.6f}]")
        print(f"  Max range: [{self.max_vals.min():.6f}, {self.max_vals.max():.6f}]")
    
    def quantize(self, embedding: np.ndarray) -> np.ndarray:
        """
        Quantize float32 embedding to uint8.
        
        Args:
            embedding: Float32 array of shape [embedding_dim] or [batch, embedding_dim]
            
        Returns:
            Uint8 array of same shape
        """
        if not self.is_fitted:
            raise RuntimeError("Quantizer not fitted. Call fit() first.")
        
        # Handle both single embedding and batch
        original_shape = embedding.shape
        if embedding.ndim == 1:
            embedding = embedding.reshape(1, -1)
        
        # Normalize to [0, 1]
        normalized = (embedding - self.min_vals) / (self.max_vals - self.min_vals)
        
        # Clip to [0, 1] to handle outliers
        normalized = np.clip(normalized, 0.0, 1.0)
        
        # Scale to [0, 255] and convert to uint8
        quantized = (normalized * 255).astype(np.uint8)
        
        # Restore original shape
        if len(original_shape) == 1:
            quantized = quantized.squeeze(0)
        
        return quantized
    
    def dequantize(self, quantized: np.ndarray) -> np.ndarray:
        """
        Dequantize uint8 embedding back to float32.
        
        Args:
            quantized: Uint8 array of shape [embedding_dim] or [batch, embedding_dim]
            
        Returns:
            Float32 array of same shape
        """
        if not self.is_fitted:
            raise RuntimeError("Quantizer not fitted. Call fit() first.")
        
        # Handle both single embedding and batch
        original_shape = quantized.shape
        if quantized.ndim == 1:
            quantized = quantized.reshape(1, -1)
        
        # Scale from [0, 255] to [0, 1]
        normalized = quantized.astype(np.float32) / 255.0
        
        # Denormalize to original range
        dequantized = normalized * (self.max_vals - self.min_vals) + self.min_vals
        
        # Restore original shape
        if len(original_shape) == 1:
            dequantized = dequantized.squeeze(0)
        
        return dequantized
    
    def measure_error(self, embeddings: np.ndarray) -> dict:
        """
        Measure quantization error on a set of embeddings.
        
        Args:
            embeddings: Float32 array of shape [num_samples, embedding_dim]
            
        Returns:
            Dictionary with error statistics
        """
        if not self.is_fitted:
            raise RuntimeError("Quantizer not fitted. Call fit() first.")
        
        # Quantize and dequantize
        quantized = self.quantize(embeddings)
        dequantized = self.dequantize(quantized)
        
        # Compute errors
        mse = np.mean((embeddings - dequantized) ** 2)
        mae = np.mean(np.abs(embeddings - dequantized))
        max_error = np.max(np.abs(embeddings - dequantized))
        
        # Per-dimension errors
        dim_mse = np.mean((embeddings - dequantized) ** 2, axis=0)
        
        return {
            'mse': float(mse),
            'mae': float(mae),
            'max_error': float(max_error),
            'dim_mse_mean': float(dim_mse.mean()),
            'dim_mse_std': float(dim_mse.std()),
            'dim_mse_max': float(dim_mse.max()),
            'num_samples': embeddings.shape[0]
        }
    
    def save(self, path: str):
        """
        Save quantization parameters to file.
        
        Args:
            path: Path to save parameters (JSON format)
        """
        if not self.is_fitted:
            raise RuntimeError("Cannot save unfitted quantizer")
        
        params = {
            'embedding_dim': self.embedding_dim,
            'min_vals': self.min_vals.tolist(),
            'max_vals': self.max_vals.tolist(),
            'is_fitted': self.is_fitted
        }
        
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        
        with open(path, 'w') as f:
            json.dump(params, f, indent=2)
        
        print(f"✓ Quantizer parameters saved to {path}")
    
    @classmethod
    def load(cls, path: str) -> 'EmbeddingQuantizer':
        """
        Load quantization parameters from file.
        
        Args:
            path: Path to parameters file
            
        Returns:
            Loaded EmbeddingQuantizer
        """
        with open(path, 'r') as f:
            params = json.load(f)
        
        quantizer = cls(embedding_dim=params['embedding_dim'])
        quantizer.min_vals = np.array(params['min_vals'])
        quantizer.max_vals = np.array(params['max_vals'])
        quantizer.is_fitted = params['is_fitted']
        
        print(f"✓ Quantizer parameters loaded from {path}")
        
        return quantizer
    
    def get_compression_stats(self) -> dict:
        """
        Calculate compression statistics.
        
        Returns:
            Dictionary with compression metrics
        """
        # Original window
        original_size = 20 * 20 * 4  # [20, 20] float32 = 1,600 bytes
        
        # Neural embedding (float32)
        embedding_size_float32 = self.embedding_dim * 4  # [64] float32 = 256 bytes
        
        # Quantized embedding (uint8)
        embedding_size_uint8 = self.embedding_dim * 1  # [64] uint8 = 64 bytes
        
        return {
            'original_bytes': original_size,
            'embedding_float32_bytes': embedding_size_float32,
            'embedding_uint8_bytes': embedding_size_uint8,
            'neural_compression_ratio': original_size / embedding_size_float32,
            'quantization_compression_ratio': embedding_size_float32 / embedding_size_uint8,
            'total_compression_ratio': original_size / embedding_size_uint8,
            'space_savings_percent': (1 - embedding_size_uint8 / original_size) * 100
        }


def fit_quantizer_on_training_set(
    model: CompressionModel,
    train_dir: Path,
    device: str = 'cpu'
) -> Tuple[EmbeddingQuantizer, np.ndarray]:
    """
    Fit quantizer on all training embeddings.
    
    Args:
        model: Trained compression model
        train_dir: Directory with training windows
        device: Device to run model on
        
    Returns:
        Tuple of (fitted_quantizer, all_embeddings)
    """
    model.eval()
    model.to(device)
    
    # Load all training windows
    train_files = [f for f in train_dir.glob("*.pkl") if f.name != "index.pkl"]
    
    print(f"\nExtracting embeddings from {len(train_files)} training windows...")
    
    all_embeddings = []
    
    with torch.no_grad():
        for window_file in tqdm(train_files, desc="Encoding"):
            # Load window
            with open(window_file, 'rb') as f:
                window = pickle.load(f)
            
            # Extract features and encode
            features = torch.FloatTensor(window.features).unsqueeze(0).to(device)
            embedding = model.encode(features)
            
            # Store embedding
            all_embeddings.append(embedding.cpu().numpy().squeeze())
    
    # Convert to array
    all_embeddings = np.array(all_embeddings)  # [num_windows, embedding_dim]
    
    print(f"\nCollected {all_embeddings.shape[0]} embeddings of dimension {all_embeddings.shape[1]}")
    
    # Fit quantizer
    print("\nFitting quantizer...")
    quantizer = EmbeddingQuantizer(embedding_dim=all_embeddings.shape[1])
    quantizer.fit(all_embeddings)
    
    return quantizer, all_embeddings


def main():
    """Main quantization script."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Fit and test embedding quantizer")
    parser.add_argument('--checkpoint', type=str, default='models/checkpoints/best_model.pt',
                       help='Path to model checkpoint')
    parser.add_argument('--device', type=str, default='auto',
                       help='Device (cpu/cuda/auto)')
    parser.add_argument('--save', type=str, default='models/checkpoints/quantizer_params.json',
                       help='Path to save quantizer parameters')
    args = parser.parse_args()
    
    # Determine device
    if args.device == 'auto':
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    else:
        device = args.device
    
    print("\n" + "=" * 70)
    print("FinanceDB - Embedding Quantization")
    print("=" * 70)
    print(f"Checkpoint: {args.checkpoint}")
    print(f"Device: {device}")
    print("=" * 70)
    
    # Load model
    print("\nLoading model...")
    checkpoint_path = Path(args.checkpoint)
    
    if not checkpoint_path.exists():
        print(f"✗ Error: Checkpoint not found at {checkpoint_path}")
        sys.exit(1)
    
    model, checkpoint = CompressionModel.load_checkpoint(str(checkpoint_path), device=device)
    
    # Fit quantizer on training set
    train_dir = Path("data/processed/train")
    if not train_dir.exists():
        print(f"✗ Error: Training directory not found at {train_dir}")
        sys.exit(1)
    
    quantizer, train_embeddings = fit_quantizer_on_training_set(model, train_dir, device)
    
    # Measure quantization error on training set
    print("\nMeasuring quantization error on training set...")
    train_errors = quantizer.measure_error(train_embeddings)
    
    print(f"\nTraining Set Quantization Error:")
    print(f"  MSE:           {train_errors['mse']:.6f}")
    print(f"  MAE:           {train_errors['mae']:.6f}")
    print(f"  Max Error:     {train_errors['max_error']:.6f}")
    
    # Get compression statistics
    stats = quantizer.get_compression_stats()
    
    print("\n" + "=" * 70)
    print("COMPRESSION STATISTICS")
    print("=" * 70)
    print(f"Original window:         {stats['original_bytes']:,} bytes (1.56 KB)")
    print(f"Neural embedding (fp32): {stats['embedding_float32_bytes']:,} bytes (0.25 KB)")
    print(f"Quantized embedding:     {stats['embedding_uint8_bytes']:,} bytes (0.06 KB)")
    print()
    print(f"Neural compression:      {stats['neural_compression_ratio']:.2f}x")
    print(f"Quantization gain:       {stats['quantization_compression_ratio']:.2f}x")
    print(f"Total compression:       {stats['total_compression_ratio']:.2f}x")
    print(f"Space savings:           {stats['space_savings_percent']:.1f}%")
    print("=" * 70)
    
    # Save quantizer
    print(f"\nSaving quantizer parameters...")
    quantizer.save(args.save)
    
    # Test save/load
    print(f"\nTesting save/load...")
    loaded_quantizer = EmbeddingQuantizer.load(args.save)
    
    # Verify loaded quantizer works
    test_embedding = train_embeddings[0]
    original_quantized = quantizer.quantize(test_embedding)
    loaded_quantized = loaded_quantizer.quantize(test_embedding)
    
    if np.array_equal(original_quantized, loaded_quantized):
        print("✓ Save/load verification passed")
    else:
        print("✗ Save/load verification failed")
    
    print("\n✓ Quantization setup complete!")
    print(f"\nOutputs:")
    print(f"  - {args.save}")


# ============================================================================
# UNIT TESTS
# ============================================================================

def test_quantizer():
    """Test the quantizer functionality."""
    print("Running Unit Tests for EmbeddingQuantizer...")
    print("=" * 70)
    
    # Create synthetic embeddings
    np.random.seed(42)
    train_embeddings = np.random.randn(1000, 64).astype(np.float32)
    test_embeddings = np.random.randn(100, 64).astype(np.float32)
    
    # Initialize quantizer
    quantizer = EmbeddingQuantizer(embedding_dim=64)
    
    # Test 1: Fit
    print("\nTest 1: Fitting quantizer...")
    quantizer.fit(train_embeddings)
    assert quantizer.is_fitted, "Quantizer not fitted"
    assert quantizer.min_vals.shape == (64,), "Wrong min_vals shape"
    assert quantizer.max_vals.shape == (64,), "Wrong max_vals shape"
    print("✓ Fit successful")
    
    # Test 2: Quantize single embedding
    print("\nTest 2: Quantize single embedding...")
    single_embedding = test_embeddings[0]
    quantized = quantizer.quantize(single_embedding)
    assert quantized.shape == (64,), f"Wrong shape: {quantized.shape}"
    assert quantized.dtype == np.uint8, f"Wrong dtype: {quantized.dtype}"
    assert quantized.min() >= 0 and quantized.max() <= 255, "Values out of range"
    print(f"✓ Quantized to uint8: min={quantized.min()}, max={quantized.max()}")
    
    # Test 3: Dequantize
    print("\nTest 3: Dequantize...")
    dequantized = quantizer.dequantize(quantized)
    assert dequantized.shape == (64,), f"Wrong shape: {dequantized.shape}"
    assert dequantized.dtype == np.float32, f"Wrong dtype: {dequantized.dtype}"
    error = np.mean(np.abs(single_embedding - dequantized))
    print(f"✓ Dequantized: MAE={error:.6f}")
    
    # Test 4: Batch quantization
    print("\nTest 4: Batch quantization...")
    quantized_batch = quantizer.quantize(test_embeddings)
    assert quantized_batch.shape == (100, 64), f"Wrong shape: {quantized_batch.shape}"
    print("✓ Batch quantization successful")
    
    # Test 5: Measure error
    print("\nTest 5: Measure error...")
    errors = quantizer.measure_error(test_embeddings)
    print(f"  MSE: {errors['mse']:.6f}")
    print(f"  MAE: {errors['mae']:.6f}")
    print(f"  Max Error: {errors['max_error']:.6f}")
    assert errors['mse'] < 1.0, "MSE too high"
    print("✓ Error measurement successful")
    
    # Test 6: Save and load
    print("\nTest 6: Save and load...")
    import tempfile
    
    with tempfile.TemporaryDirectory() as tmpdir:
        save_path = Path(tmpdir) / "quantizer.json"
        
        # Save
        quantizer.save(str(save_path))
        
        # Load
        loaded_quantizer = EmbeddingQuantizer.load(str(save_path))
        
        # Verify
        assert np.array_equal(quantizer.min_vals, loaded_quantizer.min_vals)
        assert np.array_equal(quantizer.max_vals, loaded_quantizer.max_vals)
        print("✓ Save/load successful")
    
    # Test 7: Compression stats
    print("\nTest 7: Compression statistics...")
    stats = quantizer.get_compression_stats()
    print(f"  Total compression: {stats['total_compression_ratio']:.2f}x")
    print(f"  Space savings: {stats['space_savings_percent']:.1f}%")
    assert stats['total_compression_ratio'] == 25.0, "Wrong compression ratio"
    print("✓ Compression stats correct")
    
    print("\n" + "=" * 70)
    print("✓ All tests passed!")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == '--test':
        test_quantizer()
    else:
        main()
