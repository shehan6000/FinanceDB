"""
FinanceDB - Unified Storage Manager
Coordinates DuckDB (analytical) and Qdrant (vector) storage layers.

Author: FinanceDB Project
Module: 3 - Storage Layer (Hybrid Manager)
"""

import sys
import os
from pathlib import Path
from typing import List, Dict, Optional, Tuple, Any
from datetime import datetime
import numpy as np
from loguru import logger

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from storage.duckdb_store import DuckDBStore
from storage.vector_store import QdrantStore


class StorageManager:
    """
    Unified storage manager coordinating DuckDB and Qdrant.
    
    Architecture:
    - DuckDB: Analytical queries, metadata, full embeddings
    - Qdrant: Similarity search, vector operations
    
    Features:
    - Atomic writes (both succeed or both fail)
    - Intelligent query routing
    - Unified statistics
    - Transaction handling
    """
    
    def __init__(
        self,
        duckdb_path: str = "storage/financedb.duckdb",
        qdrant_path: str = "storage/qdrant_data",
        collection_name: str = "market_embeddings",
        vector_dim: int = 64
    ):
        """
        Initialize unified storage manager.
        
        Args:
            duckdb_path: Path to DuckDB database
            qdrant_path: Path to Qdrant storage directory
            collection_name: Qdrant collection name
            vector_dim: Dimension of embedding vectors
        """
        self.duckdb_path = duckdb_path
        self.qdrant_path = qdrant_path
        self.collection_name = collection_name
        self.vector_dim = vector_dim
        
        # Initialize storage backends
        logger.info("Initializing StorageManager...")
        
        self.duckdb = DuckDBStore(db_path=duckdb_path)
        self.qdrant = QdrantStore(
            storage_path=qdrant_path,
            collection_name=collection_name
        )
        
        # Initialize Qdrant collection if needed
        try:
            self.qdrant.initialize_collection(
                vector_dim=vector_dim,
                force_recreate=False
            )
        except Exception as e:
            logger.warning(f"Collection may already exist: {e}")
        
        logger.info("StorageManager initialized successfully")
        logger.info(f"  DuckDB: {duckdb_path}")
        logger.info(f"  Qdrant: {qdrant_path}")
    
    def write(
        self,
        window_id: str,
        symbol: str,
        timestamp: datetime,
        embedding: np.ndarray,
        metadata: Optional[Dict] = None
    ) -> bool:
        """
        Write data to both DuckDB and Qdrant atomically.
        
        Args:
            window_id: Unique window identifier
            symbol: Stock ticker symbol
            timestamp: Window timestamp
            embedding: Embedding vector
            metadata: Optional metadata dictionary
            
        Returns:
            True if both writes succeed, False otherwise
        """
        try:
            # Step 1: Write to DuckDB
            duckdb_success = self.duckdb.insert(
                window_id=window_id,
                timestamp=timestamp,
                symbol=symbol,
                embedding=embedding,
                metadata=metadata
            )
            
            if not duckdb_success:
                logger.error(f"DuckDB write failed for {window_id}")
                return False
            
            # Step 2: Write to Qdrant
            payload = {
                'symbol': symbol,
                'timestamp': timestamp.isoformat(),
                'metadata': metadata or {}
            }
            
            qdrant_success = self.qdrant.insert(
                point_id=window_id,
                vector=embedding,
                payload=payload
            )
            
            if not qdrant_success:
                logger.error(f"Qdrant write failed for {window_id}")
                # Rollback: Remove from DuckDB
                logger.warning(f"Rolling back DuckDB write for {window_id}")
                # Note: DuckDB doesn't support easy rollback in this simple implementation
                # In production, use transactions
                return False
            
            logger.debug(f"Successfully wrote {window_id} to both stores")
            return True
            
        except Exception as e:
            logger.error(f"Write failed for {window_id}: {e}")
            return False
    
    def write_batch(
        self,
        records: List[Tuple[str, str, datetime, np.ndarray, Optional[Dict]]]
    ) -> Dict[str, int]:
        """
        Batch write to both stores for better performance.
        
        Args:
            records: List of tuples (window_id, symbol, timestamp, embedding, metadata)
            
        Returns:
            Dictionary with success counts
        """
        if not records:
            return {'total': 0, 'duckdb': 0, 'qdrant': 0}
        
        logger.info(f"Starting batch write of {len(records)} records")
        
        try:
            # Prepare data for DuckDB
            duckdb_records = [
                (window_id, timestamp, symbol, embedding, metadata)
                for window_id, symbol, timestamp, embedding, metadata in records
            ]
            
            # Prepare data for Qdrant
            qdrant_records = [
                (
                    window_id,
                    embedding,
                    {
                        'symbol': symbol,
                        'timestamp': timestamp.isoformat(),
                        'metadata': metadata or {}
                    }
                )
                for window_id, symbol, timestamp, embedding, metadata in records
            ]
            
            # Write to both stores
            duckdb_count = self.duckdb.insert_batch(duckdb_records)
            qdrant_count = self.qdrant.insert_batch(qdrant_records)
            
            result = {
                'total': len(records),
                'duckdb': duckdb_count,
                'qdrant': qdrant_count,
                'success': duckdb_count == qdrant_count == len(records)
            }
            
            logger.info(f"Batch write completed: DuckDB={duckdb_count}, Qdrant={qdrant_count}")
            
            if not result['success']:
                logger.warning("Batch write incomplete - data may be inconsistent")
            
            return result
            
        except Exception as e:
            logger.error(f"Batch write failed: {e}")
            return {'total': len(records), 'duckdb': 0, 'qdrant': 0, 'success': False}
    
    def read_by_id(self, window_id: str) -> Optional[Dict]:
        """
        Read data by window ID from DuckDB.
        
        Args:
            window_id: Window identifier
            
        Returns:
            Dictionary with window data or None
        """
        try:
            return self.duckdb.get_by_id(window_id)
        except Exception as e:
            logger.error(f"Failed to read {window_id}: {e}")
            return None
    
    def read_by_symbol(
        self,
        symbol: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> List[Dict]:
        """
        Query windows by symbol and date range.
        
        Args:
            symbol: Stock ticker symbol
            start_date: Optional start date
            end_date: Optional end date
            
        Returns:
            List of matching windows
        """
        try:
            # Build SQL query using DuckDBStore's query method
            sql = f"SELECT * FROM timeseries WHERE symbol = '{symbol}'"
            
            if start_date:
                sql += f" AND timestamp >= '{start_date.strftime('%Y-%m-%d %H:%M:%S')}'"
            
            if end_date:
                sql += f" AND timestamp <= '{end_date.strftime('%Y-%m-%d %H:%M:%S')}'"
            
            sql += " ORDER BY timestamp"
            
            # Use duckdb.query() instead of get_by_symbol()
            return self.duckdb.query(sql)
            
        except Exception as e:
            logger.error(f"Failed to query symbol {symbol}: {e}")
            return []
    
    def search_similar(
        self,
        query_embedding: np.ndarray,
        top_k: int = 10,
        symbol_filter: Optional[str] = None,
        enrich_metadata: bool = True
    ) -> List[Dict]:
        """
        Find similar embeddings using Qdrant, optionally enrich with DuckDB.
        
        Args:
            query_embedding: Query vector
            top_k: Number of results
            symbol_filter: Optional symbol filter
            enrich_metadata: If True, fetch full metadata from DuckDB
            
        Returns:
            List of similar windows with scores
        """
        try:
            # Search in Qdrant
            filter_conditions = {'symbol': symbol_filter} if symbol_filter else None
            results = self.qdrant.search(
                query_vector=query_embedding,
                top_k=top_k,
                filter_conditions=filter_conditions
            )
            
            # Optionally enrich with DuckDB metadata
            if enrich_metadata:
                enriched = []
                for result in results:
                    window_id = result['id']
                    full_data = self.duckdb.get_by_id(window_id)
                    
                    if full_data:
                        enriched.append({
                            'window_id': window_id,
                            'score': result['score'],
                            'symbol': full_data['symbol'],
                            'timestamp': full_data['timestamp'],
                            'metadata': full_data['metadata'],
                            'embedding': full_data['embedding']
                        })
                    else:
                        # Fallback to Qdrant data only
                        enriched.append({
                            'window_id': window_id,
                            'score': result['score'],
                            'symbol': result['payload'].get('symbol'),
                            'timestamp': result['payload'].get('timestamp'),
                            'metadata': result['payload'].get('metadata', {}),
                            'embedding': None
                        })
                
                return enriched
            else:
                return results
            
        except Exception as e:
            logger.error(f"Similarity search failed: {e}")
            return []
    
    def query_sql(self, sql: str) -> List[Dict]:
        """
        Execute SQL query on DuckDB.
        
        Args:
            sql: SQL query string
            
        Returns:
            Query results as list of dictionaries
        """
        try:
            return self.duckdb.query(sql)
        except Exception as e:
            logger.error(f"SQL query failed: {e}")
            return []
    
    def get_statistics(self) -> Dict:
        """
        Get comprehensive statistics from both stores.
        
        Returns:
            Dictionary with unified statistics
        """
        try:
            # Get basic counts
            total_windows = self.duckdb.count()
            
            # Try to get unique symbols
            unique_symbols = 0
            try:
                # Try to execute a query to count unique symbols
                unique_result = self.query_sql("SELECT COUNT(DISTINCT symbol) as count FROM timeseries")
                if unique_result and len(unique_result) > 0:
                    unique_symbols = unique_result[0]['count']
            except Exception as e:
                logger.warning(f"Could not count unique symbols: {e}")
            
            # Try to get date range
            date_range = {}
            try:
                date_result = self.query_sql(
                    "SELECT MIN(timestamp) as start, MAX(timestamp) as end FROM timeseries"
                )
                if date_result and len(date_result) > 0:
                    start = date_result[0]['start']
                    end = date_result[0]['end']
                    if start:
                        date_range['start'] = start.strftime('%Y-%m-%d') if hasattr(start, 'strftime') else str(start)
                    if end:
                        date_range['end'] = end.strftime('%Y-%m-%d') if hasattr(end, 'strftime') else str(end)
            except Exception as e:
                logger.warning(f"Could not get date range: {e}")
            
            # Try to get Qdrant statistics
            qdrant_stats = {}
            try:
                # Try to call get_collection_stats if it exists
                if hasattr(self.qdrant, 'get_collection_stats'):
                    qdrant_stats = self.qdrant.get_collection_stats()
            except Exception as e:
                logger.warning(f"Could not get Qdrant stats: {e}")
            
            # Calculate storage sizes (estimates)
            duckdb_mb = 0
            qdrant_mb = 0
            
            # Check DuckDB file size
            duckdb_path = Path(self.duckdb_path)
            if duckdb_path.exists():
                duckdb_mb = duckdb_path.stat().st_size / (1024 * 1024)
            
            # Check Qdrant directory size
            qdrant_path = Path(self.qdrant_path)
            if qdrant_path.exists():
                total_size = 0
                for file_path in qdrant_path.rglob('*'):
                    if file_path.is_file():
                        total_size += file_path.stat().st_size
                qdrant_mb = total_size / (1024 * 1024)
            
            stats = {
                'total_windows': total_windows,
                'unique_symbols': unique_symbols,
                'date_range': date_range,
                'storage': {
                    'duckdb_mb': round(duckdb_mb, 2),
                    'qdrant_mb': round(qdrant_mb, 2),
                    'total_mb': round(duckdb_mb + qdrant_mb, 2)
                }
            }
            
            return stats
            
        except Exception as e:
            logger.error(f"Failed to get statistics: {e}")
            return {}
    
    def verify_consistency(self) -> Dict:
        """
        Verify data consistency between DuckDB and Qdrant.
        
        Returns:
            Dictionary with consistency check results
        """
        try:
            duckdb_count = self.duckdb.count()
            qdrant_count = self.qdrant.count()
            
            result = {
                'duckdb_count': duckdb_count,
                'qdrant_count': qdrant_count,
                'in_sync': duckdb_count == qdrant_count,
                'difference': abs(duckdb_count - qdrant_count)
            }
            
            if not result['in_sync']:
                logger.warning(
                    f"Data inconsistency detected: "
                    f"DuckDB={duckdb_count}, Qdrant={qdrant_count}"
                )
            else:
                logger.info(f"Data consistent: {duckdb_count} records in both stores")
            
            return result
            
        except Exception as e:
            logger.error(f"Consistency check failed: {e}")
            return {'in_sync': False, 'error': str(e)}
    
    def close(self):
        """Close both storage backends."""
        logger.info("Closing StorageManager...")
        self.duckdb.close()
        self.qdrant.close()
        logger.info("StorageManager closed")
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()


# ============================================================================
# UNIT TESTS
# ============================================================================

def test_storage_manager():
    """Test StorageManager functionality."""
    import tempfile
    import shutil
    import time
    
    print("=" * 70)
    print("StorageManager Unit Tests")
    print("=" * 70)
    
    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    
    try:
        # Test 1: Initialization
        print("\nTest 1: Storage manager initialization...")
        manager = StorageManager(
            duckdb_path=str(Path(tmpdir) / "test.duckdb"),
            qdrant_path=str(Path(tmpdir) / "qdrant"),
            collection_name="test_collection",
            vector_dim=64
        )
        print("✓ StorageManager initialized")
        
        # Test 2: Single write
        print("\nTest 2: Single write (atomic)...")
        window_id = "window_001"
        symbol = "AAPL"
        timestamp = datetime(2023, 1, 1, 9, 30, 0)
        embedding = np.random.randn(64).astype(np.float32)
        metadata = {'volume': 1000000, 'volatility': 0.5}
        
        success = manager.write(window_id, symbol, timestamp, embedding, metadata)
        assert success, "Write failed"
        time.sleep(0.1)
        print("✓ Single write successful")
        
        # Test 3: Read by ID
        print("\nTest 3: Read by ID...")
        result = manager.read_by_id(window_id)
        assert result is not None, "Read failed"
        assert result['symbol'] == symbol, "Symbol mismatch"
        print(f"✓ Read successful: {result['window_id']}")
        
        # Test 4: Read by symbol
        print("\nTest 4: Read by symbol...")
        symbol_results = manager.read_by_symbol(symbol)
        assert len(symbol_results) > 0, "Should find at least one window for the symbol"
        print(f"✓ Found {len(symbol_results)} windows for {symbol}")
        
        # Test 5: Batch write - Use NEW window IDs to avoid constraint violation
        print("\nTest 5: Batch write...")
        batch_records = []
        # Start from 100 to avoid conflict with existing window_001
        for i in range(100, 110):
            batch_records.append((
                f"window_{i:03d}",
                'MSFT' if i % 2 == 0 else 'GOOGL',
                datetime(2023, 1, i-99, 9, 30, 0),  # Adjust date for new range
                np.random.randn(64).astype(np.float32),
                {'index': i}
            ))
        
        result = manager.write_batch(batch_records)
        time.sleep(0.2)
        assert result['success'], f"Batch write failed: {result}"
        print(f"✓ Batch write: {result['duckdb']} to DuckDB, {result['qdrant']} to Qdrant")
        
        # Test 6: Query by symbol with date range
        print("\nTest 6: Query by symbol with date range...")
        start_date = datetime(2023, 1, 1, 0, 0, 0)
        end_date = datetime(2023, 1, 5, 23, 59, 59)
        msft_windows = manager.read_by_symbol('MSFT', start_date, end_date)
        # Should find MSFT windows from batch in the date range
        print(f"✓ Found {len(msft_windows)} MSFT windows in date range")
        
        # Test 7: Similarity search
        print("\nTest 7: Similarity search...")
        query_vector = np.random.randn(64).astype(np.float32)
        similar = manager.search_similar(query_vector, top_k=5, enrich_metadata=True)
        assert len(similar) == 5, f"Expected 5 results, got {len(similar)}"
        print(f"✓ Similarity search found {len(similar)} windows")
        for i, s in enumerate(similar[:3]):
            print(f"  {i+1}. {s['window_id']}: score={s['score']:.4f}, symbol={s['symbol']}")
        
        # Test 8: Filtered similarity search
        print("\nTest 8: Filtered similarity search...")
        msft_similar = manager.search_similar(
            query_vector,
            top_k=10,
            symbol_filter='MSFT',
            enrich_metadata=False
        )
        assert len(msft_similar) > 0, "Should find at least one MSFT result"
        print(f"✓ Found {len(msft_similar)} similar MSFT windows")
        
        # Test 9: SQL query
        print("\nTest 9: SQL query...")
        sql_results = manager.query_sql(
            "SELECT symbol, COUNT(*) as count FROM timeseries GROUP BY symbol ORDER BY count DESC"
        )
        assert len(sql_results) > 0, "SQL query returned no results"
        print(f"✓ SQL query returned {len(sql_results)} groups")
        for row in sql_results:
            print(f"  {row['symbol']}: {row['count']} windows")
        
        # Test 10: Statistics
        print("\nTest 10: Get statistics...")
        stats = manager.get_statistics()
        # Should have 11 total windows: 1 from single write + 10 from batch
        assert stats['total_windows'] == 11, f"Statistics count mismatch: {stats['total_windows']}"
        print(f"✓ Statistics:")
        print(f"  Total windows: {stats['total_windows']}")
        print(f"  Unique symbols: {stats['unique_symbols']}")
        print(f"  Storage (DuckDB): {stats['storage']['duckdb_mb']:.2f} MB")
        print(f"  Storage (Qdrant): {stats['storage']['qdrant_mb']:.2f} MB")
        print(f"  Storage (Total): {stats['storage']['total_mb']:.2f} MB")
        
        # Test 11: Consistency check
        print("\nTest 11: Verify consistency...")
        consistency = manager.verify_consistency()
        assert consistency['in_sync'], f"Data inconsistency detected: {consistency}"
        print(f"✓ Data consistent: {consistency['duckdb_count']} records in both stores")
        
        # Test 12: Context manager
        print("\nTest 12: Context manager...")
        with StorageManager(
            duckdb_path=str(Path(tmpdir) / "test2.duckdb"),
            qdrant_path=str(Path(tmpdir) / "qdrant2"),
            collection_name="test_collection2"
        ) as mgr2:
            mgr2.write(
                "test_window",
                "TEST",
                datetime.now(),
                np.random.randn(64).astype(np.float32),
                {}
            )
            time.sleep(0.1)
            count = mgr2.duckdb.count()
            assert count == 1, f"Context manager write failed, expected 1 got {count}"
        print("✓ Context manager works")
        
        print("\n" + "=" * 70)
        print("✓ All tests passed!")
        print("=" * 70)
        
    except AssertionError as e:
        print(f"\n✗ Test failed: {e}")
        raise
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}")
        raise
    finally:
        # Cleanup
        manager.close()
        time.sleep(0.3)
        shutil.rmtree(tmpdir, ignore_errors=True)
        print(f"\nCleaned up temporary directory: {tmpdir}")

if __name__ == "__main__":
    test_storage_manager()