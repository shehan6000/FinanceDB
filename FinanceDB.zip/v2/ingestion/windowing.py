"""
FinanceDB - Window Generation Module
Creates temporal windows from time-series data for neural compression.

Author: FinanceDB Project
Module: 1 - Data Ingestion (Windowing)
"""

import uuid
import pickle
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import List, Dict, Tuple, Optional
from datetime import datetime

import numpy as np
import pandas as pd
from tqdm import tqdm
from loguru import logger


@dataclass
class DataWindow:
    """
    Represents a temporal window of financial data.
    
    Attributes:
        window_id: Unique identifier (UUID)
        timestamp: Start timestamp of the window
        symbol: Stock ticker symbol
        features: Feature array [window_size, num_features]
        metadata: Additional information (volume stats, volatility, etc.)
        split: Dataset split ('train', 'val', or 'test')
    """
    window_id: str
    timestamp: pd.Timestamp
    symbol: str
    features: np.ndarray
    metadata: Dict
    split: str
    
    def __post_init__(self):
        """Validate window data after initialization."""
        if self.features.ndim != 2:
            raise ValueError(f"Features must be 2D array, got shape {self.features.shape}")
        if self.split not in ['train', 'val', 'test']:
            raise ValueError(f"Split must be 'train', 'val', or 'test', got '{self.split}'")
    
    def to_dict(self) -> Dict:
        """Convert to dictionary (for serialization)."""
        return {
            'window_id': self.window_id,
            'timestamp': self.timestamp.isoformat(),
            'symbol': self.symbol,
            'features_shape': self.features.shape,
            'metadata': self.metadata,
            'split': self.split
        }
    
    def size_bytes(self) -> int:
        """Calculate memory footprint in bytes."""
        return (
            self.features.nbytes +
            len(pickle.dumps(self.metadata)) +
            len(self.window_id) +
            len(self.symbol) +
            100  # Approximate overhead
        )


class WindowGenerator:
    """
    Generates sliding temporal windows from time-series financial data.
    
    Features:
    - Configurable window size and stride
    - Automatic train/val/test splitting
    - Rich metadata extraction
    - Efficient batch processing
    - Progress tracking
    """
    
    def __init__(
        self,
        window_size: int = 20,
        stride: int = 1,
        train_ratio: float = 0.70,
        val_ratio: float = 0.15,
        test_ratio: float = 0.15,
        output_dir: str = "data/processed"
    ):
        """
        Initialize window generator.
        
        Args:
            window_size: Number of timesteps in each window
            stride: Step size for sliding window
            train_ratio: Proportion of data for training
            val_ratio: Proportion of data for validation
            test_ratio: Proportion of data for testing
            output_dir: Directory to save processed windows
        """
        if not np.isclose(train_ratio + val_ratio + test_ratio, 1.0):
            raise ValueError("Split ratios must sum to 1.0")
        
        self.window_size = window_size
        self.stride = stride
        self.train_ratio = train_ratio
        self.val_ratio = val_ratio
        self.test_ratio = test_ratio
        
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Create split subdirectories
        for split in ['train', 'val', 'test']:
            (self.output_dir / split).mkdir(exist_ok=True)
        
        logger.info(f"Initialized WindowGenerator")
        logger.info(f"  Window size: {window_size}")
        logger.info(f"  Stride: {stride}")
        logger.info(f"  Split ratios: {train_ratio:.0%} / {val_ratio:.0%} / {test_ratio:.0%}")
    
    def _determine_split(self, index: int, total: int) -> str:
        """
        Determine which split a window belongs to based on temporal order.
        
        Uses chronological splitting to avoid data leakage:
        - First 70% → train
        - Next 15% → val
        - Last 15% → test
        """
        ratio = index / total
        
        if ratio < self.train_ratio:
            return 'train'
        elif ratio < (self.train_ratio + self.val_ratio):
            return 'val'
        else:
            return 'test'
    
    def _compute_metadata(
        self,
        features: np.ndarray,
        symbol: str,
        timestamp: pd.Timestamp,
        original_data: Optional[pd.DataFrame] = None
    ) -> Dict:
        """
        Compute metadata statistics for a window.
        
        Args:
            features: Feature array for the window
            symbol: Stock symbol
            timestamp: Window start timestamp
            original_data: Original OHLCV data (optional, for volume stats)
            
        Returns:
            Dictionary with metadata statistics
        """
        metadata = {
            'symbol': symbol,
            'timestamp': timestamp.isoformat(),
            'window_size': features.shape[0],
            'num_features': features.shape[1],
            
            # Feature statistics
            'mean': float(np.mean(features)),
            'std': float(np.std(features)),
            'min': float(np.min(features)),
            'max': float(np.max(features)),
            
            # Per-feature statistics (for important features)
            'returns_mean': float(np.mean(features[:, 0])) if features.shape[1] > 0 else None,
            'volatility_mean': float(np.mean(features[:, 1])) if features.shape[1] > 1 else None,
        }
        
        # Add volume statistics if original data available
        if original_data is not None and 'Volume' in original_data.columns:
            volume_data = original_data['Volume'].values
            metadata['volume_mean'] = float(np.mean(volume_data))
            metadata['volume_std'] = float(np.std(volume_data))
            metadata['volume_total'] = float(np.sum(volume_data))
        
        return metadata
    
    def create_windows_single(
        self,
        features_df: pd.DataFrame,
        symbol: str,
        original_data: Optional[pd.DataFrame] = None
    ) -> List[DataWindow]:
        """
        Create windows from a single symbol's feature data.
        
        Args:
            features_df: DataFrame with features [timestamps, features]
            symbol: Stock ticker symbol
            original_data: Original OHLCV data (for metadata)
            
        Returns:
            List of DataWindow objects
        """
        if len(features_df) < self.window_size:
            logger.warning(
                f"{symbol}: Insufficient data ({len(features_df)} rows, "
                f"need {self.window_size})"
            )
            return []
        
        windows = []
        total_possible = (len(features_df) - self.window_size) // self.stride + 1
        
        for i in range(0, len(features_df) - self.window_size + 1, self.stride):
            # Extract window
            window_features = features_df.iloc[i:i + self.window_size].values
            window_timestamp = features_df.index[i]
            
            # Get original data for this window (if available)
            window_original = None
            if original_data is not None:
                window_original = original_data.iloc[i:i + self.window_size]
            
            # Compute metadata
            metadata = self._compute_metadata(
                window_features,
                symbol,
                window_timestamp,
                window_original
            )
            
            # Determine split
            split = self._determine_split(len(windows), total_possible)
            
            # Create DataWindow object
            window = DataWindow(
                window_id=str(uuid.uuid4()),
                timestamp=window_timestamp,
                symbol=symbol,
                features=window_features.astype(np.float32),  # Save memory
                metadata=metadata,
                split=split
            )
            
            windows.append(window)
        
        logger.info(
            f"{symbol}: Created {len(windows)} windows "
            f"(train: {sum(w.split == 'train' for w in windows)}, "
            f"val: {sum(w.split == 'val' for w in windows)}, "
            f"test: {sum(w.split == 'test' for w in windows)})"
        )
        
        return windows
    
    def create_windows_batch(
        self,
        features_dict: Dict[str, pd.DataFrame],
        original_data_dict: Optional[Dict[str, pd.DataFrame]] = None
    ) -> List[DataWindow]:
        """
        Create windows for multiple symbols.
        
        Args:
            features_dict: Dict mapping symbol -> features DataFrame
            original_data_dict: Dict mapping symbol -> original OHLCV DataFrame
            
        Returns:
            List of all DataWindow objects
        """
        logger.info(f"Creating windows for {len(features_dict)} symbols")
        
        all_windows = []
        
        with tqdm(features_dict.items(), desc="Creating windows", unit="symbol") as pbar:
            for symbol, features_df in pbar:
                pbar.set_postfix_str(f"Current: {symbol}")
                
                # Get original data if available
                original_data = None
                if original_data_dict is not None:
                    original_data = original_data_dict.get(symbol)
                
                # Create windows for this symbol
                windows = self.create_windows_single(
                    features_df,
                    symbol,
                    original_data
                )
                
                all_windows.extend(windows)
        
        logger.info(f"Created {len(all_windows)} total windows")
        return all_windows
    
    def save_windows(self, windows: List[DataWindow]) -> Dict[str, int]:
        """
        Save windows to disk organized by split.
        
        Args:
            windows: List of DataWindow objects
            
        Returns:
            Dictionary with counts per split
        """
        logger.info(f"Saving {len(windows)} windows to {self.output_dir}")
        
        counts = {'train': 0, 'val': 0, 'test': 0}
        
        with tqdm(windows, desc="Saving windows", unit="window") as pbar:
            for window in pbar:
                # Determine output path
                split_dir = self.output_dir / window.split
                filename = f"{window.symbol}_{window.window_id}.pkl"
                filepath = split_dir / filename
                
                # Save window
                try:
                    with open(filepath, 'wb') as f:
                        pickle.dump(window, f, protocol=pickle.HIGHEST_PROTOCOL)
                    counts[window.split] += 1
                except Exception as e:
                    logger.error(f"Failed to save window {window.window_id}: {e}")
        
        # Save index file for each split
        for split in ['train', 'val', 'test']:
            split_windows = [w for w in windows if w.split == split]
            if split_windows:
                index_data = [w.to_dict() for w in split_windows]
                index_path = self.output_dir / split / "index.pkl"
                
                with open(index_path, 'wb') as f:
                    pickle.dump(index_data, f)
                
                logger.info(f"Saved {split} index: {len(index_data)} windows")
        
        return counts
    
    def load_windows(self, split: str = 'train') -> List[DataWindow]:
        """
        Load windows from disk for a specific split.
        
        Args:
            split: Which split to load ('train', 'val', or 'test')
            
        Returns:
            List of DataWindow objects
        """
        split_dir = self.output_dir / split
        
        if not split_dir.exists():
            logger.warning(f"Split directory does not exist: {split_dir}")
            return []
        
        window_files = list(split_dir.glob("*.pkl"))
        # Exclude index file
        window_files = [f for f in window_files if f.name != "index.pkl"]
        
        logger.info(f"Loading {len(window_files)} windows from {split} split")
        
        windows = []
        for filepath in tqdm(window_files, desc=f"Loading {split}", unit="window"):
            try:
                with open(filepath, 'rb') as f:
                    window = pickle.load(f)
                windows.append(window)
            except Exception as e:
                logger.error(f"Failed to load {filepath}: {e}")
        
        return windows
    
    def get_statistics(self, windows: List[DataWindow]) -> Dict:
        """
        Compute statistics about generated windows.
        
        Args:
            windows: List of DataWindow objects
            
        Returns:
            Dictionary with comprehensive statistics
        """
        if not windows:
            return {}
        
        # Split counts
        split_counts = {
            'train': sum(w.split == 'train' for w in windows),
            'val': sum(w.split == 'val' for w in windows),
            'test': sum(w.split == 'test' for w in windows)
        }
        
        # Symbol distribution
        symbols = [w.symbol for w in windows]
        symbol_counts = pd.Series(symbols).value_counts().to_dict()
        
        # Temporal coverage
        timestamps = [w.timestamp for w in windows]
        date_range = {
            'start': min(timestamps).strftime('%Y-%m-%d'),
            'end': max(timestamps).strftime('%Y-%m-%d'),
            'span_days': (max(timestamps) - min(timestamps)).days
        }
        
        # Memory usage
        total_bytes = sum(w.size_bytes() for w in windows)
        
        # Feature statistics
        all_features = np.concatenate([w.features for w in windows], axis=0)
        
        stats = {
            'total_windows': len(windows),
            'split_counts': split_counts,
            'split_percentages': {
                k: f"{v/len(windows)*100:.1f}%" 
                for k, v in split_counts.items()
            },
            'unique_symbols': len(set(symbols)),
            'windows_per_symbol': symbol_counts,
            'date_range': date_range,
            'window_size': windows[0].features.shape[0],
            'num_features': windows[0].features.shape[1],
            'total_memory_mb': total_bytes / (1024 * 1024),
            'avg_window_kb': total_bytes / len(windows) / 1024,
            'feature_stats': {
                'mean': float(np.mean(all_features)),
                'std': float(np.std(all_features)),
                'min': float(np.min(all_features)),
                'max': float(np.max(all_features))
            }
        }
        
        return stats


def main():
    """Demo: Create windows from feature data."""
    print("=" * 60)
    print("FinanceDB - Window Generation Demo")
    print("=" * 60)
    print()
    
    # This would normally load real feature data
    # For demo, we'll create synthetic data
    print("Loading feature data...")
    
    # Simulate features for 3 symbols
    np.random.seed(42)
    symbols = ['AAPL', 'MSFT', 'GOOGL']
    
    features_dict = {}
    original_data_dict = {}
    
    for symbol in symbols:
        # Create 200 days of synthetic features (20 features)
        dates = pd.date_range('2020-01-01', periods=200, freq='D')
        features = pd.DataFrame(
            np.random.randn(200, 20),
            index=dates,
            columns=[f'feature_{i}' for i in range(20)]
        )
        features_dict[symbol] = features
        
        # Create synthetic original data (for metadata)
        original_data_dict[symbol] = pd.DataFrame({
            'Volume': np.random.randint(1000000, 5000000, 200)
        }, index=dates)
    
    print(f"Loaded features for {len(features_dict)} symbols")
    print()
    
    # Initialize window generator
    generator = WindowGenerator(
        window_size=20,
        stride=1,
        train_ratio=0.70,
        val_ratio=0.15,
        test_ratio=0.15,
        output_dir="data/processed"
    )
    
    # Create windows
    print("Creating windows...")
    windows = generator.create_windows_batch(features_dict, original_data_dict)
    print()
    
    # Save windows
    print("Saving windows to disk...")
    counts = generator.save_windows(windows)
    print()
    
    # Get statistics
    print("Computing statistics...")
    stats = generator.get_statistics(windows)
    
    # Display results
    print("=" * 60)
    print("WINDOW GENERATION SUMMARY")
    print("=" * 60)
    print()
    print(f"Total Windows Created: {stats['total_windows']:,}")
    print(f"Unique Symbols: {stats['unique_symbols']}")
    print(f"Window Size: {stats['window_size']} timesteps")
    print(f"Number of Features: {stats['num_features']}")
    print()
    
    print("Split Distribution:")
    for split, count in stats['split_counts'].items():
        pct = stats['split_percentages'][split]
        print(f"  {split.capitalize()}: {count:,} windows ({pct})")
    print()
    
    print("Date Range:")
    print(f"  Start: {stats['date_range']['start']}")
    print(f"  End: {stats['date_range']['end']}")
    print(f"  Span: {stats['date_range']['span_days']} days")
    print()
    
    print("Windows per Symbol:")
    for symbol, count in sorted(stats['windows_per_symbol'].items()):
        print(f"  {symbol}: {count:,}")
    print()
    
    print("Memory Usage:")
    print(f"  Total: {stats['total_memory_mb']:.2f} MB")
    print(f"  Per window: {stats['avg_window_kb']:.2f} KB")
    print()
    
    print("Feature Statistics (across all windows):")
    for stat, value in stats['feature_stats'].items():
        print(f"  {stat.capitalize()}: {value:.4f}")
    print()
    
    print("=" * 60)
    print("✓ Window generation complete!")
    print()
    print(f"Output directory: {generator.output_dir.absolute()}")
    print(f"  - train/: {counts['train']:,} windows")
    print(f"  - val/: {counts['val']:,} windows")
    print(f"  - test/: {counts['test']:,} windows")


if __name__ == "__main__":
    main()
