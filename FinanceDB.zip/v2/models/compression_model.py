"""
FinanceDB - Neural Compression Model
LSTM-based encoder-decoder for compressing financial time-series windows.

Author: FinanceDB Project
Module: 2 - Neural Compression Engine
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Optional


class CompressionModel(nn.Module):
    """
    LSTM-based compression model for financial time-series windows.
    
    Architecture:
    - Encoder: 2-layer LSTM (hidden_dim=128) compresses to 64-D embedding
    - Decoder: 2-layer LSTM (hidden_dim=128) reconstructs from embedding
    
    Input:  [batch, 20, 20] (20 days × 20 features)
    Embedding: [batch, 64]
    Output: [batch, 20, 20] (reconstructed)
    
    Loss: MSE between input and reconstruction
    """
    
    def __init__(
        self,
        input_dim: int = 20,
        hidden_dim: int = 128,
        embedding_dim: int = 64,
        num_layers: int = 2,
        seq_len: int = 20
    ):
        """
        Initialize compression model.
        
        Args:
            input_dim: Number of input features (20)
            hidden_dim: LSTM hidden dimension (128)
            embedding_dim: Compressed embedding dimension (64)
            num_layers: Number of LSTM layers (2)
            seq_len: Sequence length (20 days)
        """
        super().__init__()
        
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.embedding_dim = embedding_dim
        self.num_layers = num_layers
        self.seq_len = seq_len
        
        # ====================================================================
        # ENCODER: [batch, 20, 20] → [batch, 64]
        # ====================================================================
        self.encoder_lstm = nn.LSTM(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=0.1 if num_layers > 1 else 0
        )
        
        # Compress LSTM final hidden state to embedding
        self.encoder_fc = nn.Linear(hidden_dim, embedding_dim)
        
        # ====================================================================
        # DECODER: [batch, 64] → [batch, 20, 20]
        # ====================================================================
        
        # Expand embedding to initial hidden state
        self.decoder_fc = nn.Linear(embedding_dim, hidden_dim)
        
        # LSTM decoder
        self.decoder_lstm = nn.LSTM(
            input_size=input_dim,  # We'll feed previous outputs
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=0.1 if num_layers > 1 else 0
        )
        
        # Output layer
        self.output_fc = nn.Linear(hidden_dim, input_dim)
    
    def encode(self, x: torch.Tensor) -> torch.Tensor:
        """
        Encode input window to compressed embedding.
        
        Args:
            x: Input tensor [batch, seq_len, features]
               Shape: [batch, 20, 20]
        
        Returns:
            Embedding tensor [batch, embedding_dim]
            Shape: [batch, 64]
        """
        batch_size = x.size(0)
        
        # Pass through encoder LSTM
        # Output: [batch, seq_len, hidden_dim]
        # hidden: ([num_layers, batch, hidden_dim], [num_layers, batch, hidden_dim])
        _, (hidden, cell) = self.encoder_lstm(x)
        
        # Use final layer's hidden state
        final_hidden = hidden[-1]  # [batch, hidden_dim]
        
        # Compress to embedding
        embedding = self.encoder_fc(final_hidden)  # [batch, embedding_dim]
        
        return embedding
    
    def decode(self, embedding: torch.Tensor) -> torch.Tensor:
        """
        Decode embedding to reconstructed window.
        
        Args:
            embedding: Embedding tensor [batch, embedding_dim]
                      Shape: [batch, 64]
        
        Returns:
            Reconstructed tensor [batch, seq_len, features]
            Shape: [batch, 20, 20]
        """
        batch_size = embedding.size(0)
        
        # Expand embedding to hidden state
        hidden = self.decoder_fc(embedding)  # [batch, hidden_dim]
        
        # Prepare initial hidden and cell states for LSTM
        # Shape: [num_layers, batch, hidden_dim]
        h0 = hidden.unsqueeze(0).repeat(self.num_layers, 1, 1)
        c0 = torch.zeros_like(h0)
        
        # Initialize decoder input (zeros)
        decoder_input = torch.zeros(
            batch_size, self.seq_len, self.input_dim,
            device=embedding.device
        )
        
        # Autoregressive decoding: use previous output as next input
        outputs = []
        hidden_state = (h0, c0)
        
        for t in range(self.seq_len):
            # Get current input
            if t == 0:
                current_input = decoder_input[:, t:t+1, :]  # [batch, 1, input_dim]
            else:
                current_input = output.unsqueeze(1)  # [batch, 1, input_dim]
            
            # LSTM step
            lstm_out, hidden_state = self.decoder_lstm(current_input, hidden_state)
            # lstm_out: [batch, 1, hidden_dim]
            
            # Generate output for this timestep
            output = self.output_fc(lstm_out.squeeze(1))  # [batch, input_dim]
            outputs.append(output)
        
        # Stack outputs: [batch, seq_len, input_dim]
        reconstruction = torch.stack(outputs, dim=1)
        
        return reconstruction
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Full forward pass: encode and decode.
        
        Args:
            x: Input tensor [batch, seq_len, features]
               Shape: [batch, 20, 20]
        
        Returns:
            Reconstructed tensor [batch, seq_len, features]
            Shape: [batch, 20, 20]
        """
        embedding = self.encode(x)
        reconstruction = self.decode(embedding)
        return reconstruction
    
    def get_compression_ratio(self) -> float:
        """
        Calculate theoretical compression ratio.
        
        Returns:
            Compression ratio (original size / compressed size)
        """
        original_size = self.seq_len * self.input_dim  # 20 * 20 = 400
        compressed_size = self.embedding_dim  # 64
        return original_size / compressed_size
    
    def count_parameters(self) -> dict:
        """
        Count model parameters.
        
        Returns:
            Dictionary with parameter counts
        """
        total_params = sum(p.numel() for p in self.parameters())
        trainable_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        
        encoder_params = (
            sum(p.numel() for p in self.encoder_lstm.parameters()) +
            sum(p.numel() for p in self.encoder_fc.parameters())
        )
        
        decoder_params = (
            sum(p.numel() for p in self.decoder_lstm.parameters()) +
            sum(p.numel() for p in self.decoder_fc.parameters()) +
            sum(p.numel() for p in self.output_fc.parameters())
        )
        
        return {
            'encoder': encoder_params,
            'decoder': decoder_params,
            'total': total_params,
            'trainable': trainable_params
        }
    
    def summary(self):
        """Print model summary."""
        print("=" * 70)
        print("CompressionModel Summary")
        print("=" * 70)
        print(f"\nArchitecture:")
        print(f"  Type:             LSTM-based Autoencoder")
        print(f"  Encoder:          2-layer LSTM (hidden_dim={self.hidden_dim})")
        print(f"  Decoder:          2-layer LSTM (hidden_dim={self.hidden_dim})")
        print(f"\nShapes:")
        print(f"  Input:            [batch, {self.seq_len}, {self.input_dim}]")
        print(f"  Embedding:        [batch, {self.embedding_dim}]")
        print(f"  Output:           [batch, {self.seq_len}, {self.input_dim}]")
        
        print(f"\nCompression:")
        print(f"  Original size:    {self.seq_len * self.input_dim} floats")
        print(f"  Compressed size:  {self.embedding_dim} floats")
        print(f"  Ratio:            {self.get_compression_ratio():.2f}x")
        
        params = self.count_parameters()
        print(f"\nParameters:")
        print(f"  Encoder:          {params['encoder']:,}")
        print(f"  Decoder:          {params['decoder']:,}")
        print(f"  Total:            {params['total']:,}")
        print(f"  Trainable:        {params['trainable']:,}")
        
        print("\n" + "=" * 70)
    
    def save_checkpoint(
        self,
        path: str,
        optimizer: Optional[torch.optim.Optimizer] = None,
        epoch: int = 0,
        loss: float = 0.0
    ):
        """
        Save model checkpoint.
        
        Args:
            path: Path to save checkpoint
            optimizer: Optimizer state (optional)
            epoch: Current epoch
            loss: Current loss
        """
        checkpoint = {
            'epoch': epoch,
            'model_state_dict': self.state_dict(),
            'loss': loss,
            'config': {
                'input_dim': self.input_dim,
                'hidden_dim': self.hidden_dim,
                'embedding_dim': self.embedding_dim,
                'num_layers': self.num_layers,
                'seq_len': self.seq_len
            }
        }
        
        if optimizer is not None:
            checkpoint['optimizer_state_dict'] = optimizer.state_dict()
        
        torch.save(checkpoint, path)
        print(f"✓ Checkpoint saved to {path}")
    
    @classmethod
    def load_checkpoint(cls, path: str, device: str = 'cpu'):
        """
        Load model from checkpoint.
        
        Args:
            path: Path to checkpoint file
            device: Device to load model to ('cpu' or 'cuda')
        
        Returns:
            Tuple of (model, checkpoint_dict)
        """
        checkpoint = torch.load(path, map_location=device)
        
        # Create model with saved config
        config = checkpoint['config']
        model = cls(
            input_dim=config['input_dim'],
            hidden_dim=config['hidden_dim'],
            embedding_dim=config['embedding_dim'],
            num_layers=config['num_layers'],
            seq_len=config['seq_len']
        )
        
        # Load state dict
        model.load_state_dict(checkpoint['model_state_dict'])
        model.to(device)
        
        print(f"✓ Model loaded from {path}")
        print(f"  Epoch: {checkpoint['epoch']}")
        print(f"  Loss: {checkpoint['loss']:.6f}")
        
        return model, checkpoint


# ============================================================================
# LOSS FUNCTION
# ============================================================================

def reconstruction_loss(output: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """
    Compute MSE reconstruction loss.
    
    Args:
        output: Model output [batch, seq_len, features]
        target: Target input [batch, seq_len, features]
    
    Returns:
        MSE loss (scalar)
    """
    return F.mse_loss(output, target)


# ============================================================================
# UNIT TESTS
# ============================================================================

def test_model():
    """Test the compression model."""
    print("Running Unit Tests for CompressionModel...")
    print("=" * 70)
    
    # Create model
    model = CompressionModel(
        input_dim=20,
        hidden_dim=128,
        embedding_dim=64,
        num_layers=2,
        seq_len=20
    )
    
    # Print summary
    model.summary()
    
    # Test 1: Forward pass
    print("\nTest 1: Forward pass...")
    batch_size = 32
    x = torch.randn(batch_size, 20, 20)  # Random input
    
    reconstruction = model(x)
    
    assert reconstruction.shape == (batch_size, 20, 20), \
        f"Wrong reconstruction shape: {reconstruction.shape}"
    print(f"✓ Forward pass successful")
    print(f"  Input shape:          {x.shape}")
    print(f"  Reconstruction shape: {reconstruction.shape}")
    
    # Test 2: Encode only
    print("\nTest 2: Encode only...")
    embedding = model.encode(x)
    assert embedding.shape == (batch_size, 64), \
        f"Wrong embedding shape: {embedding.shape}"
    print(f"✓ Encoding successful: {embedding.shape}")
    
    # Test 3: Decode only
    print("\nTest 3: Decode only...")
    reconstruction = model.decode(embedding)
    assert reconstruction.shape == (batch_size, 20, 20), \
        f"Wrong decoding shape: {reconstruction.shape}"
    print(f"✓ Decoding successful: {reconstruction.shape}")
    
    # Test 4: Loss computation
    print("\nTest 4: Loss computation...")
    loss = reconstruction_loss(reconstruction, x)
    print(f"✓ Loss computed: {loss.item():.6f}")
    
    # Test 5: Gradient flow
    print("\nTest 5: Gradient flow...")
    loss.backward()
    
    has_gradients = all(
        p.grad is not None for p in model.parameters() if p.requires_grad
    )
    assert has_gradients, "Some parameters don't have gradients"
    print(f"✓ Gradients computed successfully")
    
    # Test 6: Save and load checkpoint
    print("\nTest 6: Save/load checkpoint...")
    import tempfile
    
    with tempfile.TemporaryDirectory() as tmpdir:
        checkpoint_path = f"{tmpdir}/test_checkpoint.pt"
        
        # Save
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
        model.save_checkpoint(checkpoint_path, optimizer, epoch=10, loss=0.123)
        
        # Load
        loaded_model, checkpoint = CompressionModel.load_checkpoint(checkpoint_path)
        
        # Verify
        assert checkpoint['epoch'] == 10
        assert checkpoint['loss'] == 0.123
        print(f"✓ Checkpoint save/load successful")
    
    # Test 7: Device compatibility
    print("\nTest 7: Device compatibility...")
    if torch.cuda.is_available():
        model_cuda = model.to('cuda')
        x_cuda = x.to('cuda')
        reconstruction_cuda = model_cuda(x_cuda)
        assert reconstruction_cuda.device.type == 'cuda'
        print(f"✓ CUDA support working")
    else:
        print(f"⊘ CUDA not available (CPU only)")
    
    print("\n" + "=" * 70)
    print("✓ All tests passed!")
    print("\nModel ready for training.")
    print(f"\nCompression ratio: {model.get_compression_ratio():.2f}x")
    print(f"Total parameters: {model.count_parameters()['total']:,}")


if __name__ == "__main__":
    test_model()
