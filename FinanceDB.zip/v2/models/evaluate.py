"""
FinanceDB - Model Evaluation Pipeline
Evaluates the trained compression model on the test set.

Author: FinanceDB Project
Module: 2 - Neural Compression Engine (Evaluation)

Usage:
    python -m models.evaluate
    python -m models.evaluate --checkpoint models/checkpoints/best_model.pt
    python -m models.evaluate --num-samples 10
"""

import sys
import pickle
from pathlib import Path
from typing import List, Dict, Tuple
from datetime import datetime

import torch
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import our compression model and DataWindow
from models.compression_model import CompressionModel, reconstruction_loss
from ingestion.windowing import DataWindow


class ModelEvaluator:
    """
    Evaluates the compression model on test data.
    """
    
    def __init__(
        self,
        model: CompressionModel,
        test_dir: Path,
        device: str = 'cpu'
    ):
        """
        Initialize evaluator.
        
        Args:
            model: Trained compression model
            test_dir: Directory containing test windows
            device: Device to run evaluation on
        """
        self.model = model.to(device)
        self.model.eval()
        self.test_dir = test_dir
        self.device = device
        
        # Load test windows
        self.test_files = [
            f for f in test_dir.glob("*.pkl") 
            if f.name != "index.pkl"
        ]
        
        print(f"Found {len(self.test_files)} test windows")
    
    def load_window(self, idx: int) -> Tuple[torch.Tensor, DataWindow]:
        """
        Load a single test window.
        
        Args:
            idx: Index of window to load
            
        Returns:
            Tuple of (features_tensor, window_object)
        """
        window_file = self.test_files[idx]
        
        with open(window_file, 'rb') as f:
            window = pickle.load(f)
        
        features = torch.FloatTensor(window.features).unsqueeze(0)  # [1, seq_len, features]
        
        return features, window
    
    def evaluate_all(self) -> Dict:
        """
        Evaluate model on all test windows.
        
        Returns:
            Dictionary with evaluation metrics
        """
        print("\n" + "=" * 70)
        print("Evaluating Model on Test Set")
        print("=" * 70)
        
        all_mse = []
        all_errors = []
        feature_errors = [[] for _ in range(self.model.input_dim)]
        
        with torch.no_grad():
            for idx in tqdm(range(len(self.test_files)), desc="Evaluating"):
                # Load window
                features, _ = self.load_window(idx)
                features = features.to(self.device)
                
                # Forward pass
                reconstruction = self.model(features)
                
                # Compute errors
                mse = torch.mean((reconstruction - features) ** 2).item()
                all_mse.append(mse)
                
                # Per-element errors
                errors = (reconstruction - features).squeeze(0).cpu().numpy()
                all_errors.append(errors)
                
                # Per-feature errors
                feature_mse = torch.mean((reconstruction - features) ** 2, dim=(0, 1)).cpu().numpy()
                for feat_idx, feat_error in enumerate(feature_mse):
                    feature_errors[feat_idx].append(feat_error)
        
        # Aggregate metrics
        results = {
            'overall_mse': np.mean(all_mse),
            'mse_std': np.std(all_mse),
            'mse_min': np.min(all_mse),
            'mse_max': np.max(all_mse),
            'all_mse': all_mse,
            'all_errors': all_errors,
            'feature_mse': [np.mean(errors) for errors in feature_errors],
            'feature_std': [np.std(errors) for errors in feature_errors],
            'num_windows': len(self.test_files)
        }
        
        # Print summary
        print(f"\n{'='*70}")
        print("Evaluation Results")
        print(f"{'='*70}")
        print(f"Test windows:       {results['num_windows']:,}")
        print(f"Overall MSE:        {results['overall_mse']:.6f}")
        print(f"MSE Std Dev:        {results['mse_std']:.6f}")
        print(f"MSE Range:          [{results['mse_min']:.6f}, {results['mse_max']:.6f}]")
        print(f"{'='*70}\n")
        
        return results
    
    def visualize_reconstructions(
        self,
        num_samples: int = 5,
        save_path: str = "docs/reconstructions.png"
    ):
        """
        Visualize original vs reconstructed windows.
        
        Args:
            num_samples: Number of random samples to visualize
            save_path: Path to save visualization
        """
        # Create output directory
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Select random windows
        indices = np.random.choice(len(self.test_files), num_samples, replace=False)
        
        # Create figure
        fig, axes = plt.subplots(num_samples, 3, figsize=(15, 3*num_samples))
        if num_samples == 1:
            axes = axes.reshape(1, -1)
        
        with torch.no_grad():
            for i, idx in enumerate(indices):
                # Load window
                features, window = self.load_window(idx)
                features = features.to(self.device)
                
                # Reconstruct
                reconstruction = self.model(features)
                
                # Convert to numpy
                original = features.squeeze(0).cpu().numpy()
                reconstructed = reconstruction.squeeze(0).cpu().numpy()
                error = np.abs(original - reconstructed)
                
                # Plot original
                ax1 = axes[i, 0]
                im1 = ax1.imshow(original.T, aspect='auto', cmap='viridis')
                ax1.set_title(f'Original (Window {idx})', fontweight='bold')
                ax1.set_xlabel('Time Step')
                ax1.set_ylabel('Feature')
                plt.colorbar(im1, ax=ax1)
                
                # Plot reconstruction
                ax2 = axes[i, 1]
                im2 = ax2.imshow(reconstructed.T, aspect='auto', cmap='viridis')
                ax2.set_title('Reconstructed', fontweight='bold')
                ax2.set_xlabel('Time Step')
                ax2.set_ylabel('Feature')
                plt.colorbar(im2, ax=ax2)
                
                # Plot error
                ax3 = axes[i, 2]
                im3 = ax3.imshow(error.T, aspect='auto', cmap='Reds')
                ax3.set_title(f'Absolute Error (MSE: {np.mean(error**2):.6f})', fontweight='bold')
                ax3.set_xlabel('Time Step')
                ax3.set_ylabel('Feature')
                plt.colorbar(im3, ax=ax3)
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✓ Reconstructions saved to {save_path}")
        plt.close()
    
    def plot_error_distribution(
        self,
        results: Dict,
        save_path: str = "docs/error_distribution.png"
    ):
        """
        Plot distribution of reconstruction errors.
        
        Args:
            results: Results dictionary from evaluate_all()
            save_path: Path to save plot
        """
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        
        # Plot 1: MSE distribution
        ax1 = axes[0]
        ax1.hist(results['all_mse'], bins=50, color='steelblue', alpha=0.7, edgecolor='black')
        ax1.axvline(results['overall_mse'], color='red', linestyle='--', linewidth=2,
                   label=f'Mean: {results["overall_mse"]:.6f}')
        ax1.set_xlabel('MSE', fontsize=12)
        ax1.set_ylabel('Frequency', fontsize=12)
        ax1.set_title('Reconstruction Error Distribution', fontsize=14, fontweight='bold')
        ax1.legend(fontsize=10)
        ax1.grid(True, alpha=0.3)
        
        # Plot 2: Error heatmap (average across all windows)
        ax2 = axes[1]
        avg_error = np.mean([np.abs(err) for err in results['all_errors']], axis=0)
        im = ax2.imshow(avg_error.T, aspect='auto', cmap='Reds')
        ax2.set_xlabel('Time Step', fontsize=12)
        ax2.set_ylabel('Feature Index', fontsize=12)
        ax2.set_title('Average Absolute Error Heatmap', fontsize=14, fontweight='bold')
        plt.colorbar(im, ax=ax2, label='Absolute Error')
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✓ Error distribution saved to {save_path}")
        plt.close()
    
    def plot_feature_importance(
        self,
        results: Dict,
        save_path: str = "docs/feature_importance.png"
    ):
        """
        Plot which features compress best (lowest error).
        
        Args:
            results: Results dictionary from evaluate_all()
            save_path: Path to save plot
        """
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Feature names (from feature_extractor.py)
        feature_names = [
            'returns', 'volatility', 'volume_change', 'hl_spread', 'close_position',
            'rsi', 'macd', 'macd_signal', 'macd_histogram',
            'bb_upper', 'bb_lower', 'bb_width', 'bb_position',
            'momentum_5d', 'momentum_10d', 'momentum_20d',
            'volume_momentum', 'sma_ratio', 'ema_ratio', 'atr'
        ]
        
        feature_mse = results['feature_mse']
        feature_std = results['feature_std']
        
        # Sort by MSE (ascending)
        sorted_indices = np.argsort(feature_mse)
        sorted_names = [feature_names[i] for i in sorted_indices]
        sorted_mse = [feature_mse[i] for i in sorted_indices]
        sorted_std = [feature_std[i] for i in sorted_indices]
        
        # Create plot
        fig, ax = plt.subplots(figsize=(12, 8))
        
        y_pos = np.arange(len(sorted_names))
        colors = plt.cm.RdYlGn_r(np.linspace(0.2, 0.8, len(sorted_names)))
        
        bars = ax.barh(y_pos, sorted_mse, xerr=sorted_std, color=colors, 
                      alpha=0.7, edgecolor='black', linewidth=0.5)
        
        ax.set_yticks(y_pos)
        ax.set_yticklabels(sorted_names, fontsize=10)
        ax.set_xlabel('Mean Squared Error', fontsize=12)
        ax.set_title('Feature Reconstruction Quality\n(Lower is Better)', 
                    fontsize=14, fontweight='bold')
        ax.grid(True, alpha=0.3, axis='x')
        
        # Add value labels
        for i, (bar, mse) in enumerate(zip(bars, sorted_mse)):
            ax.text(mse + max(sorted_mse)*0.01, bar.get_y() + bar.get_height()/2,
                   f'{mse:.6f}', va='center', fontsize=8)
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✓ Feature importance saved to {save_path}")
        plt.close()
        
        # Return top/bottom 5 features
        top_5 = [(sorted_names[i], sorted_mse[i]) for i in range(5)]
        bottom_5 = [(sorted_names[i], sorted_mse[i]) for i in range(-5, 0)]
        
        return top_5, bottom_5
    
    def generate_report(
        self,
        results: Dict,
        top_features: List[Tuple],
        bottom_features: List[Tuple],
        save_path: str = "docs/evaluation_report.txt"
    ):
        """
        Generate text evaluation report.
        
        Args:
            results: Results dictionary from evaluate_all()
            top_features: Top 5 best-compressed features
            bottom_features: Bottom 5 worst-compressed features
            save_path: Path to save report
        """
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Calculate compression stats
        original_bytes = self.model.seq_len * self.model.input_dim * 4
        compressed_bytes = self.model.embedding_dim * 4
        compression_ratio = original_bytes / compressed_bytes
        
        report = []
        report.append("=" * 70)
        report.append("FINANCEDB - MODEL EVALUATION REPORT")
        report.append("=" * 70)
        report.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append("")
        
        # Model configuration
        report.append("-" * 70)
        report.append("MODEL CONFIGURATION")
        report.append("-" * 70)
        report.append(f"Architecture:       LSTM-based Autoencoder")
        report.append(f"Input shape:        [{self.model.seq_len}, {self.model.input_dim}]")
        report.append(f"Embedding size:     {self.model.embedding_dim}")
        report.append(f"Hidden dimension:   {self.model.hidden_dim}")
        report.append(f"Number of layers:   {self.model.num_layers}")
        params = self.model.count_parameters()
        report.append(f"Total parameters:   {params['total']:,}")
        report.append("")
        
        # Compression statistics
        report.append("-" * 70)
        report.append("COMPRESSION STATISTICS")
        report.append("-" * 70)
        report.append(f"Original size:      {original_bytes:,} bytes ({original_bytes/1024:.2f} KB)")
        report.append(f"Compressed size:    {compressed_bytes:,} bytes ({compressed_bytes/1024:.2f} KB)")
        report.append(f"Compression ratio:  {compression_ratio:.2f}x")
        report.append(f"Space savings:      {(1 - 1/compression_ratio)*100:.1f}%")
        report.append("")
        
        # Evaluation metrics
        report.append("-" * 70)
        report.append("RECONSTRUCTION QUALITY")
        report.append("-" * 70)
        report.append(f"Test windows:       {results['num_windows']:,}")
        report.append(f"Overall MSE:        {results['overall_mse']:.6f}")
        report.append(f"MSE Std Dev:        {results['mse_std']:.6f}")
        report.append(f"MSE Range:          [{results['mse_min']:.6f}, {results['mse_max']:.6f}]")
        report.append("")
        
        # Top 5 best features
        report.append("-" * 70)
        report.append("TOP 5 BEST-COMPRESSED FEATURES (Lowest Error)")
        report.append("-" * 70)
        for i, (name, mse) in enumerate(top_features, 1):
            report.append(f"{i}. {name:20s} MSE: {mse:.6f}")
        report.append("")
        
        # Bottom 5 worst features
        report.append("-" * 70)
        report.append("TOP 5 WORST-COMPRESSED FEATURES (Highest Error)")
        report.append("-" * 70)
        for i, (name, mse) in enumerate(bottom_features, 1):
            report.append(f"{i}. {name:20s} MSE: {mse:.6f}")
        report.append("")
        
        # Summary
        report.append("-" * 70)
        report.append("SUMMARY")
        report.append("-" * 70)
        report.append(f"✓ Model achieves {compression_ratio:.2f}x compression")
        report.append(f"✓ Average reconstruction error: {results['overall_mse']:.6f} MSE")
        report.append(f"✓ Best feature: {top_features[0][0]} (MSE: {top_features[0][1]:.6f})")
        report.append(f"✓ Challenging feature: {bottom_features[0][0]} (MSE: {bottom_features[0][1]:.6f})")
        report.append("")
        report.append("Generated visualizations:")
        report.append("  - docs/reconstructions.png      (Original vs Reconstructed)")
        report.append("  - docs/error_distribution.png   (Error histogram & heatmap)")
        report.append("  - docs/feature_importance.png   (Feature-wise quality)")
        report.append("")
        report.append("=" * 70)
        
        # Write to file (use UTF-8 encoding for cross-platform compatibility)
        with open(save_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report))
        
        # Print to console
        print('\n'.join(report))
        
        print(f"\n✓ Evaluation report saved to {save_path}")


def main():
    """Main evaluation script."""
    import argparse
    
    # Parse arguments
    parser = argparse.ArgumentParser(description="Evaluate FinanceDB Compression Model")
    parser.add_argument('--checkpoint', type=str, default='models/checkpoints/best_model.pt',
                       help='Path to model checkpoint')
    parser.add_argument('--num-samples', type=int, default=5,
                       help='Number of samples to visualize')
    parser.add_argument('--device', type=str, default='auto',
                       help='Device (cpu/cuda/auto)')
    args = parser.parse_args()
    
    # Determine device
    if args.device == 'auto':
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    else:
        device = args.device
    
    print("\n" + "=" * 70)
    print("FinanceDB - Model Evaluation")
    print("=" * 70)
    print(f"Checkpoint: {args.checkpoint}")
    print(f"Device: {device}")
    print(f"Visualization samples: {args.num_samples}")
    print("=" * 70 + "\n")
    
    # Load model
    print("Loading model...")
    checkpoint_path = Path(args.checkpoint)
    
    if not checkpoint_path.exists():
        print(f"✗ Error: Checkpoint not found at {checkpoint_path}")
        print(f"  Please train the model first: python -m models.train")
        sys.exit(1)
    
    model, checkpoint = CompressionModel.load_checkpoint(str(checkpoint_path), device=device)
    print()
    
    # Initialize evaluator
    test_dir = Path("data/processed/test")
    if not test_dir.exists():
        print(f"✗ Error: Test directory not found at {test_dir}")
        print(f"  Please run the data pipeline first: python scripts/01_download_and_process.py")
        sys.exit(1)
    
    evaluator = ModelEvaluator(model, test_dir, device=device)
    
    try:
        # Evaluate on all test windows
        results = evaluator.evaluate_all()
        
        # Generate visualizations
        print("\nGenerating visualizations...")
        evaluator.visualize_reconstructions(
            num_samples=args.num_samples,
            save_path="docs/reconstructions.png"
        )
        
        evaluator.plot_error_distribution(
            results,
            save_path="docs/error_distribution.png"
        )
        
        top_features, bottom_features = evaluator.plot_feature_importance(
            results,
            save_path="docs/feature_importance.png"
        )
        
        # Generate report
        print("\nGenerating evaluation report...")
        evaluator.generate_report(
            results,
            top_features,
            bottom_features,
            save_path="docs/evaluation_report.txt"
        )
        
        print("\n✓ Evaluation completed successfully!")
        print(f"\nOutputs:")
        print(f"  - docs/evaluation_report.txt")
        print(f"  - docs/reconstructions.png")
        print(f"  - docs/error_distribution.png")
        print(f"  - docs/feature_importance.png")
        
    except Exception as e:
        print(f"\n✗ Evaluation failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()