#!/usr/bin/env python3
"""
FinanceDB - Database Ingestion Script (Corrected)
Loads processed windows into DuckDB and Qdrant with duplicate handling.
"""

import sys
import argparse
import pickle
import time
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any

import torch
import numpy as np
from tqdm import tqdm
from loguru import logger
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.compression_model import CompressionModel
from models.quantizer import EmbeddingQuantizer
from ingestion.windowing import DataWindow
from storage.storage_manager import StorageManager

console = Console()

class DatabaseIngestion:
    def __init__(
        self,
        model_path: str = "models/checkpoints/best_model.pt",
        quantizer_path: str = "models/checkpoints/quantizer_params.json",
        processed_dir: str = "data/processed",
        storage_dir: str = "storage",
        batch_size: int = 100,
        use_quantization: bool = False,
        device: str = "auto"
    ):
        self.model_path = Path(model_path)
        self.quantizer_path = Path(quantizer_path)
        self.processed_dir = Path(processed_dir)
        self.storage_dir = Path(storage_dir)
        self.batch_size = batch_size
        self.use_quantization = use_quantization
        
        self.device = device if device != "auto" else ("cuda" if torch.cuda.is_available() else "cpu")
        
        self.stats = {
            'start_time': datetime.now(),
            'windows_processed': 0,
            'windows_failed': 0,
            'embeddings_created': 0,
            'db_inserts': {'train': 0, 'val': 0, 'test': 0},
            'total_inserted': 0
        }

    def load_model(self) -> CompressionModel:
        console.print("\n[bold cyan]Loading Compression Model...[/bold cyan]")
        if not self.model_path.exists():
            raise FileNotFoundError(f"Model not found: {self.model_path}")
        
        model, _ = CompressionModel.load_checkpoint(str(self.model_path), device=self.device)
        model.eval()
        console.print(f"✓ Model loaded (Dim: {model.embedding_dim})")
        return model

    def load_windows(self, split: str) -> List[DataWindow]:
        split_dir = self.processed_dir / split
        if not split_dir.exists():
            return []
        
        window_files = [f for f in split_dir.glob("*.pkl") if f.name != "index.pkl"]
        windows = []
        for filepath in tqdm(window_files, desc=f"Loading {split}", leave=False):
            try:
                with open(filepath, 'rb') as f:
                    windows.append(pickle.load(f))
            except Exception as e:
                logger.error(f"Load failed: {filepath} - {e}")
                self.stats['windows_failed'] += 1
        return windows

    def encode_windows(self, windows: List[DataWindow], model: CompressionModel, quantizer: Any = None) -> List[Dict]:
        encoded = []
        with torch.no_grad():
            for window in windows:
                try:
                    feat = torch.FloatTensor(window.features).unsqueeze(0).to(self.device)
                    emb = model.encode(feat).cpu().numpy().squeeze()
                    
                    if quantizer:
                        emb = quantizer.dequantize(quantizer.quantize(emb))

                    encoded.append({
                        'window_id': str(window.window_id),
                        'symbol': window.symbol,
                        'timestamp': window.timestamp,
                        'embedding': emb.astype(np.float32),
                        'metadata': window.metadata
                    })
                    self.stats['embeddings_created'] += 1
                except Exception as e:
                    self.stats['windows_failed'] += 1
        return encoded

    def ingest_batch(self, records: List[Dict], storage_manager: StorageManager, split: str) -> int:
        batch = [(r['window_id'], r['symbol'], r['timestamp'], r['embedding'], r['metadata']) for r in records]
        result = storage_manager.write_batch(batch)
        
        # Track counts even if partial success (e.g. some were duplicates)
        self.stats['db_inserts'][split] += result.get('duckdb', 0)
        self.stats['total_inserted'] += result.get('duckdb', 0)
        return result.get('duckdb', 0)

    def run(self):
        console.print(Panel.fit("[bold yellow]FinanceDB Ingestion System[/bold yellow]"))
        try:
            model = self.load_model()
            quantizer = EmbeddingQuantizer.load(str(self.quantizer_path)) if self.use_quantization else None
            
            storage_manager = StorageManager(
                duckdb_path=str(self.storage_dir / "financedb.duckdb"),
                qdrant_path=str(self.storage_dir / "qdrant_data"),
                collection_name="market_embeddings",
                vector_dim=model.embedding_dim
            )

            for split in ['train', 'val', 'test']:
                console.print(f"\n[bold cyan]Processing {split.upper()}...[/bold cyan]")
                windows = self.load_windows(split)
                if not windows: continue
                
                for i in range(0, len(windows), self.batch_size):
                    batch = windows[i:i + self.batch_size]
                    encoded = self.encode_windows(batch, model, quantizer)
                    self.ingest_batch(encoded, storage_manager, split)
                    self.stats['windows_processed'] += len(batch)

            self.stats['end_time'] = datetime.now()
            storage_manager.close()
            console.print("\n[bold green]✓ Ingestion Finished Successfully![/bold green]")
        except Exception as e:
            logger.exception("Pipeline Error")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--batch-size', type=int, default=100)
    parser.add_argument('--quantize', action='store_true')
    args = parser.parse_args()
    
    ingestor = DatabaseIngestion(batch_size=args.batch_size, use_quantization=args.quantize)
    ingestor.run()