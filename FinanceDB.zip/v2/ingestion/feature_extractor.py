"""
FinanceDB - Feature Extraction Module
Computes technical indicators and features from OHLCV financial data.

Author: FinanceDB Project
Module: 1 - Data Ingestion (Feature Engineering)
"""

import numpy as np
import pandas as pd
from typing import Optional, Tuple
from loguru import logger
import warnings

warnings.filterwarnings('ignore')


class FinancialFeatureExtractor:
    """
    Extracts technical analysis features from OHLCV stock data.
    
    Features computed:
    1. Returns (log returns)
    2. Volatility (rolling standard deviation)
    3. Volume changes (log volume ratio)
    4. High-Low spread (normalized)
    5. Close position within range
    6. RSI (Relative Strength Index)
    7. MACD (Moving Average Convergence Divergence)
    8. MACD Signal
    9. MACD Histogram
    10. Bollinger Band Upper
    11. Bollinger Band Lower
    12. Bollinger Band Width
    13. Bollinger Band Position
    14. Price momentum (5-day)
    15. Price momentum (10-day)
    16. Price momentum (20-day)
    17. Volume momentum (5-day)
    18. SMA ratio (Close / SMA20)
    19. EMA ratio (Close / EMA12)
    20. Average True Range (ATR)
    """
    
    def __init__(
        self,
        volatility_window: int = 20,
        rsi_period: int = 14,
        macd_fast: int = 12,
        macd_slow: int = 26,
        macd_signal: int = 9,
        bb_period: int = 20,
        bb_std: float = 2.0,
        atr_period: int = 14,
        normalize: bool = True
    ):
        """
        Initialize feature extractor with technical indicator parameters.
        
        Args:
            volatility_window: Window for volatility calculation
            rsi_period: Period for RSI calculation
            macd_fast: Fast EMA period for MACD
            macd_slow: Slow EMA period for MACD
            macd_signal: Signal line period for MACD
            bb_period: Period for Bollinger Bands
            bb_std: Number of standard deviations for Bollinger Bands
            atr_period: Period for Average True Range
            normalize: Whether to z-score normalize features
        """
        self.volatility_window = volatility_window
        self.rsi_period = rsi_period
        self.macd_fast = macd_fast
        self.macd_slow = macd_slow
        self.macd_signal = macd_signal
        self.bb_period = bb_period
        self.bb_std = bb_std
        self.atr_period = atr_period
        self.normalize = normalize
        
        logger.info("Initialized FinancialFeatureExtractor")
    
    def _compute_returns(self, prices: pd.Series) -> pd.Series:
        """Compute log returns."""
        return np.log(prices / prices.shift(1))
    
    def _compute_volatility(self, returns: pd.Series, window: int) -> pd.Series:
        """Compute rolling volatility (std of returns)."""
        return returns.rolling(window=window).std()
    
    def _compute_volume_change(self, volume: pd.Series) -> pd.Series:
        """Compute log volume ratio."""
        return np.log(volume / volume.shift(1))
    
    def _compute_high_low_spread(
        self, 
        high: pd.Series, 
        low: pd.Series, 
        close: pd.Series
    ) -> pd.Series:
        """Compute normalized High-Low spread."""
        return (high - low) / close
    
    def _compute_close_position(
        self, 
        close: pd.Series, 
        high: pd.Series, 
        low: pd.Series
    ) -> pd.Series:
        """Compute where close is within the day's range (0=low, 1=high)."""
        range_val = high - low
        range_val = range_val.replace(0, np.nan)  # Avoid division by zero
        return (close - low) / range_val
    
    def _compute_rsi(self, prices: pd.Series, period: int) -> pd.Series:
        """
        Compute Relative Strength Index.
        
        RSI = 100 - (100 / (1 + RS))
        where RS = Average Gain / Average Loss
        """
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        
        rs = gain / loss.replace(0, np.nan)
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    def _compute_macd(
        self, 
        prices: pd.Series, 
        fast: int, 
        slow: int, 
        signal: int
    ) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """
        Compute MACD (Moving Average Convergence Divergence).
        
        Returns:
            macd: MACD line (fast EMA - slow EMA)
            signal_line: Signal line (EMA of MACD)
            histogram: MACD histogram (MACD - signal)
        """
        ema_fast = prices.ewm(span=fast, adjust=False).mean()
        ema_slow = prices.ewm(span=slow, adjust=False).mean()
        
        macd = ema_fast - ema_slow
        signal_line = macd.ewm(span=signal, adjust=False).mean()
        histogram = macd - signal_line
        
        return macd, signal_line, histogram
    
    def _compute_bollinger_bands(
        self, 
        prices: pd.Series, 
        period: int, 
        std_dev: float
    ) -> Tuple[pd.Series, pd.Series, pd.Series, pd.Series]:
        """
        Compute Bollinger Bands.
        
        Returns:
            upper: Upper band (SMA + std_dev * std)
            lower: Lower band (SMA - std_dev * std)
            width: Band width ((upper - lower) / sma)
            position: Price position within bands
        """
        sma = prices.rolling(window=period).mean()
        std = prices.rolling(window=period).std()
        
        upper = sma + (std_dev * std)
        lower = sma - (std_dev * std)
        
        width = (upper - lower) / sma
        position = (prices - lower) / (upper - lower)
        
        return upper, lower, width, position
    
    def _compute_momentum(self, prices: pd.Series, period: int) -> pd.Series:
        """Compute price momentum (rate of change)."""
        return (prices - prices.shift(period)) / prices.shift(period)
    
    def _compute_sma_ratio(self, prices: pd.Series, period: int = 20) -> pd.Series:
        """Compute ratio of price to Simple Moving Average."""
        sma = prices.rolling(window=period).mean()
        return prices / sma
    
    def _compute_ema_ratio(self, prices: pd.Series, period: int = 12) -> pd.Series:
        """Compute ratio of price to Exponential Moving Average."""
        ema = prices.ewm(span=period, adjust=False).mean()
        return prices / ema
    
    def _compute_atr(
        self, 
        high: pd.Series, 
        low: pd.Series, 
        close: pd.Series, 
        period: int
    ) -> pd.Series:
        """
        Compute Average True Range (volatility indicator).
        
        True Range = max(high - low, |high - prev_close|, |low - prev_close|)
        ATR = EMA of True Range
        """
        prev_close = close.shift(1)
        
        tr1 = high - low
        tr2 = (high - prev_close).abs()
        tr3 = (low - prev_close).abs()
        
        true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = true_range.ewm(span=period, adjust=False).mean()
        
        return atr / close  # Normalize by price
    
    def _handle_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Handle missing values in features.
        
        Strategy:
        1. Forward fill (carry last valid observation forward)
        2. Backward fill (for any remaining NaNs at start)
        3. Fill remaining with 0
        """
        df = df.fillna(method='ffill')
        df = df.fillna(method='bfill')
        df = df.fillna(0)
        return df
    
    def _normalize_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Normalize features using z-score normalization.
        
        z = (x - mean) / std
        """
        normalized = df.copy()
        
        for col in df.columns:
            mean = df[col].mean()
            std = df[col].std()
            
            if std > 0:
                normalized[col] = (df[col] - mean) / std
            else:
                normalized[col] = 0  # Constant feature
        
        return normalized
    
    def extract_features(self, ohlcv_data: pd.DataFrame) -> pd.DataFrame:
        """
        Extract all technical features from OHLCV data.
        
        Args:
            ohlcv_data: DataFrame with columns [Open, High, Low, Close, Volume]
            
        Returns:
            DataFrame with 20 engineered features
        """
        # Validate input
        required_cols = ['Open', 'High', 'Low', 'Close', 'Volume']
        missing_cols = [col for col in required_cols if col not in ohlcv_data.columns]
        if missing_cols:
            raise ValueError(f"Missing required columns: {missing_cols}")
        
        logger.info(f"Extracting features from {len(ohlcv_data)} rows of data")
        
        # Extract price and volume series
        open_price = ohlcv_data['Open']
        high = ohlcv_data['High']
        low = ohlcv_data['Low']
        close = ohlcv_data['Close']
        volume = ohlcv_data['Volume']
        
        # Initialize features dictionary
        features = {}
        
        # 1. Returns
        features['returns'] = self._compute_returns(close)
        
        # 2. Volatility
        features['volatility'] = self._compute_volatility(
            features['returns'], 
            self.volatility_window
        )
        
        # 3. Volume changes
        features['volume_change'] = self._compute_volume_change(volume)
        
        # 4. High-Low spread
        features['hl_spread'] = self._compute_high_low_spread(high, low, close)
        
        # 5. Close position within range
        features['close_position'] = self._compute_close_position(close, high, low)
        
        # 6. RSI
        features['rsi'] = self._compute_rsi(close, self.rsi_period)
        
        # 7-9. MACD components
        macd, macd_signal, macd_hist = self._compute_macd(
            close, 
            self.macd_fast, 
            self.macd_slow, 
            self.macd_signal
        )
        features['macd'] = macd
        features['macd_signal'] = macd_signal
        features['macd_histogram'] = macd_hist
        
        # 10-13. Bollinger Bands
        bb_upper, bb_lower, bb_width, bb_position = self._compute_bollinger_bands(
            close, 
            self.bb_period, 
            self.bb_std
        )
        features['bb_upper'] = bb_upper
        features['bb_lower'] = bb_lower
        features['bb_width'] = bb_width
        features['bb_position'] = bb_position
        
        # 14-16. Price momentum (multiple timeframes)
        features['momentum_5d'] = self._compute_momentum(close, 5)
        features['momentum_10d'] = self._compute_momentum(close, 10)
        features['momentum_20d'] = self._compute_momentum(close, 20)
        
        # 17. Volume momentum
        features['volume_momentum'] = self._compute_momentum(volume, 5)
        
        # 18. SMA ratio
        features['sma_ratio'] = self._compute_sma_ratio(close, 20)
        
        # 19. EMA ratio
        features['ema_ratio'] = self._compute_ema_ratio(close, 12)
        
        # 20. Average True Range
        features['atr'] = self._compute_atr(high, low, close, self.atr_period)
        
        # Create DataFrame
        features_df = pd.DataFrame(features, index=ohlcv_data.index)
        
        # Handle missing values
        features_df = self._handle_missing_values(features_df)
        
        # Normalize if requested
        if self.normalize:
            features_df = self._normalize_features(features_df)
        
        logger.info(f"Extracted {len(features_df.columns)} features")
        logger.info(f"Feature names: {list(features_df.columns)}")
        
        return features_df
    
    def extract_features_batch(
        self, 
        data_dict: dict
    ) -> dict:
        """
        Extract features for multiple symbols.
        
        Args:
            data_dict: Dictionary mapping symbol -> OHLCV DataFrame
            
        Returns:
            Dictionary mapping symbol -> features DataFrame
        """
        logger.info(f"Extracting features for {len(data_dict)} symbols")
        
        features_dict = {}
        for symbol, ohlcv_data in data_dict.items():
            try:
                features = self.extract_features(ohlcv_data)
                features_dict[symbol] = features
                logger.info(f"{symbol}: Extracted {len(features.columns)} features")
            except Exception as e:
                logger.error(f"{symbol}: Feature extraction failed - {e}")
        
        return features_dict


# ============================================================================
# UNIT TESTS
# ============================================================================

def test_feature_extractor():
    """Unit tests for FinancialFeatureExtractor."""
    
    print("Running Unit Tests for FinancialFeatureExtractor...")
    print("=" * 60)
    
    # Create synthetic test data
    np.random.seed(42)
    dates = pd.date_range('2023-01-01', periods=100, freq='D')
    
    test_data = pd.DataFrame({
        'Open': 100 + np.cumsum(np.random.randn(100) * 0.5),
        'High': 102 + np.cumsum(np.random.randn(100) * 0.5),
        'Low': 98 + np.cumsum(np.random.randn(100) * 0.5),
        'Close': 100 + np.cumsum(np.random.randn(100) * 0.5),
        'Volume': np.random.randint(1000000, 5000000, 100)
    }, index=dates)
    
    # Ensure High >= Low
    test_data['High'] = test_data[['Open', 'Close', 'High']].max(axis=1)
    test_data['Low'] = test_data[['Open', 'Close', 'Low']].min(axis=1)
    
    # Initialize extractor
    extractor = FinancialFeatureExtractor(normalize=True)
    
    # Test 1: Basic extraction
    print("\nTest 1: Basic feature extraction...")
    features = extractor.extract_features(test_data)
    assert features.shape[0] == test_data.shape[0], "Row count mismatch"
    assert features.shape[1] == 20, f"Expected 20 features, got {features.shape[1]}"
    print(f"✓ Extracted {features.shape[1]} features from {features.shape[0]} rows")
    
    # Test 2: No missing values
    print("\nTest 2: Missing value handling...")
    missing_count = features.isnull().sum().sum()
    assert missing_count == 0, f"Found {missing_count} missing values"
    print(f"✓ No missing values in output")
    
    # Test 3: Normalization
    print("\nTest 3: Feature normalization...")
    if extractor.normalize:
        for col in features.columns:
            mean = features[col].mean()
            std = features[col].std()
            assert abs(mean) < 0.1, f"{col}: Mean not close to 0 ({mean})"
            assert abs(std - 1.0) < 0.1 or std == 0, f"{col}: Std not close to 1 ({std})"
        print("✓ All features normalized (mean≈0, std≈1)")
    
    # Test 4: RSI range
    print("\nTest 4: RSI range validation...")
    extractor_raw = FinancialFeatureExtractor(normalize=False)
    features_raw = extractor_raw.extract_features(test_data)
    rsi = features_raw['rsi'].dropna()
    assert rsi.min() >= 0 and rsi.max() <= 100, f"RSI out of range [0, 100]: [{rsi.min()}, {rsi.max()}]"
    print(f"✓ RSI in valid range: [{rsi.min():.2f}, {rsi.max():.2f}]")
    
    # Test 5: Feature names
    print("\nTest 5: Feature names...")
    expected_features = [
        'returns', 'volatility', 'volume_change', 'hl_spread', 'close_position',
        'rsi', 'macd', 'macd_signal', 'macd_histogram',
        'bb_upper', 'bb_lower', 'bb_width', 'bb_position',
        'momentum_5d', 'momentum_10d', 'momentum_20d',
        'volume_momentum', 'sma_ratio', 'ema_ratio', 'atr'
    ]
    assert list(features.columns) == expected_features, "Feature names mismatch"
    print("✓ All expected feature names present")
    
    # Test 6: Batch extraction
    print("\nTest 6: Batch extraction...")
    data_dict = {'AAPL': test_data, 'MSFT': test_data}
    features_batch = extractor.extract_features_batch(data_dict)
    assert len(features_batch) == 2, "Batch extraction failed"
    assert all(f.shape[1] == 20 for f in features_batch.values()), "Feature count mismatch in batch"
    print(f"✓ Batch extraction successful for {len(features_batch)} symbols")
    
    # Summary
    print("\n" + "=" * 60)
    print("✓ All tests passed!")
    print(f"\nFeature Summary:")
    print(f"  Total features: {features.shape[1]}")
    print(f"  Sample period: {len(test_data)} days")
    print(f"  Memory usage: {features.memory_usage(deep=True).sum() / 1024:.2f} KB")
    print("\nFeature Statistics:")
    print(features.describe().round(2))


if __name__ == "__main__":
    test_feature_extractor()
