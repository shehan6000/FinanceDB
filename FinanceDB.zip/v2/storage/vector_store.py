"""
FinanceDB - Qdrant Vector Store
Vector database storage for semantic similarity search on embeddings.

Author: FinanceDB Project
Module: 3 - Storage Layer (Vector Database)
"""

from pathlib import Path
from typing import List, Dict, Optional, Tuple, Union
from datetime import datetime
import uuid
import numpy as np
from loguru import logger

from qdrant_client import QdrantClient
from qdrant_client.models import (
    Distance,
    VectorParams,
    PointStruct,
    Filter,
    FieldCondition,
    MatchValue,
    Range,
    SearchRequest
)


class QdrantStore:
    """
    Qdrant-based vector database for financial time-series embeddings.
    
    Features:
    - Fast similarity search (k-NN)
    - Local storage (no server required)
    - Metadata filtering
    - Batch insertion
    """
    
    def __init__(
        self,
        storage_path: str = "storage/qdrant_data",
        collection_name: str = "market_embeddings",
        enable_logging: bool = True
    ):
        """
        Initialize Qdrant client and collection.
        
        Args:
            storage_path: Directory for Qdrant data storage
            collection_name: Name of the collection (default: market_embeddings)
            enable_logging: Whether to enable file logging
        """
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self.collection_name = collection_name
        
        # Initialize Qdrant client in local mode (no server needed)
        self.client = QdrantClient(path=str(self.storage_path))
        
        # Setup logging
        self.log_handler_id = None
        if enable_logging:
            self.log_handler_id = logger.add(
                self.storage_path / "qdrant_store.log",
                rotation="10 MB",
                level="INFO"
            )
        
        logger.info(f"Initialized QdrantStore at {self.storage_path}")
        logger.info(f"Collection: {self.collection_name}, Local mode (no server)")
    
    def initialize_collection(
        self,
        collection_name: Optional[str] = None,
        vector_dim: int = 64,
        distance: Distance = Distance.COSINE,
        force_recreate: bool = False
    ):
        """
        Create or recreate the embeddings collection.
        
        Args:
            collection_name: Collection name (uses default if None)
            vector_dim: Dimension of embedding vectors
            distance: Distance metric (COSINE, EUCLID, DOT)
            force_recreate: If True, delete existing collection
        """
        if collection_name:
            self.collection_name = collection_name
        
        try:
            # Check if collection exists
            collections = self.client.get_collections().collections
            exists = any(c.name == self.collection_name for c in collections)
            
            if exists:
                if force_recreate:
                    logger.info(f"Deleting existing collection: {self.collection_name}")
                    self.client.delete_collection(self.collection_name)
                else:
                    logger.info(f"Collection {self.collection_name} already exists")
                    return
            
            # Create collection
            self.client.create_collection(
                collection_name=self.collection_name,
                vectors_config=VectorParams(
                    size=vector_dim,
                    distance=distance
                )
            )
            
            logger.info(
                f"Created collection: {self.collection_name} "
                f"(dim={vector_dim}, distance={distance})"
            )
            
        except Exception as e:
            logger.error(f"Failed to initialize collection: {e}")
            raise
    
    def insert(
        self,
        point_id: str,
        vector: np.ndarray,
        payload: Optional[Dict] = None
    ) -> bool:
        """
        Insert a single embedding into the vector store.
        
        Args:
            point_id: Unique identifier (window_id, will be converted to UUID)
            vector: Embedding vector (numpy array, 64-D)
            payload: Metadata dict (timestamp, symbol, etc.)
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Convert numpy to list
            vector_list = vector.tolist() if isinstance(vector, np.ndarray) else vector
            
            # Convert string ID to UUID hash
            point_uuid = str(uuid.uuid5(uuid.NAMESPACE_DNS, point_id))
            
            # Store original ID in payload
            if payload is None:
                payload = {}
            payload['original_id'] = point_id
            
            # Create point
            point = PointStruct(
                id=point_uuid,
                vector=vector_list,
                payload=payload
            )
            
            # Insert (HNSW index updated automatically)
            self.client.upsert(
                collection_name=self.collection_name,
                points=[point]
            )
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to insert point {point_id}: {e}")
            return False
    
    def insert_batch(
        self,
        records: List[Tuple[str, np.ndarray, Optional[Dict]]]
    ) -> int:
        """
        Batch insert multiple embeddings for better performance.
        
        Args:
            records: List of tuples (point_id, vector, payload)
            
        Returns:
            Number of successfully inserted records
        """
        if not records:
            return 0
        
        try:
            # Create points
            points = []
            for point_id, vector, payload in records:
                vector_list = vector.tolist() if isinstance(vector, np.ndarray) else vector
                
                # Convert string ID to UUID hash
                point_uuid = str(uuid.uuid5(uuid.NAMESPACE_DNS, point_id))
                
                # Store original ID in payload
                if payload is None:
                    payload = {}
                payload['original_id'] = point_id
                
                point = PointStruct(
                    id=point_uuid,
                    vector=vector_list,
                    payload=payload
                )
                points.append(point)
            
            # Batch insert (HNSW index updated automatically)
            self.client.upsert(
                collection_name=self.collection_name,
                points=points
            )
            
            logger.info(f"Batch inserted {len(records)} vectors into HNSW index")
            return len(records)
            
        except Exception as e:
            logger.error(f"Batch insert failed: {e}")
            return 0
    
    def search(
        self,
        query_vector: np.ndarray,
        top_k: int = 10,
        filter_conditions: Optional[Dict] = None,
        min_score: Optional[float] = None
    ) -> List[Dict]:
        """
        Find top_k most similar embeddings to query vector.
        
        Args:
            query_vector: Query embedding vector
            top_k: Number of nearest neighbors to return
            filter_conditions: Optional filter dict, e.g., {'symbol': 'AAPL'}
            min_score: Optional minimum similarity score threshold
            
        Returns:
            List of dicts with {id, score, payload}
        """
        try:
            # Convert numpy to list
            query_list = query_vector.tolist() if isinstance(query_vector, np.ndarray) else query_vector
            
            # Build filter if needed
            query_filter = None
            if filter_conditions:
                must_conditions = []
                for key, value in filter_conditions.items():
                    must_conditions.append(
                        FieldCondition(
                            key=key,
                            match=MatchValue(value=value)
                        )
                    )
                query_filter = Filter(must=must_conditions)
            
            # Search using HNSW index (automatically created by Qdrant)
            # Note: Using query() method instead of search() for newer Qdrant versions
            results = self.client.query_points(
                collection_name=self.collection_name,
                query=query_list,
                limit=top_k,
                query_filter=query_filter,
                score_threshold=min_score
            )
            
            # Format results
            output = []
            for hit in results.points:
                output.append({
                    'id': hit.payload.get('original_id', hit.id),  # Return original ID
                    'score': hit.score,
                    'payload': hit.payload
                })
            
            return output
            
        except Exception as e:
            logger.error(f"Similarity search failed: {e}")
            return []
    
    def get_by_id(self, point_id: str) -> Optional[Dict]:
        """
        Retrieve a single vector by ID.
        
        Args:
            point_id: Point identifier (original ID, not UUID)
            
        Returns:
            Dictionary with vector and metadata or None
        """
        try:
            # Convert original ID to UUID for lookup
            point_uuid = str(uuid.uuid5(uuid.NAMESPACE_DNS, point_id))
            
            result = self.client.retrieve(
                collection_name=self.collection_name,
                ids=[point_uuid],
                with_vectors=True,
                with_payload=True
            )
            
            if result:
                point = result[0]
                return {
                    'id': point.payload.get('original_id', point.id),
                    'vector': np.array(point.vector) if point.vector else None,
                    'payload': point.payload
                }
            
            return None
            
        except Exception as e:
            logger.error(f"Failed to get point {point_id}: {e}")
            return None
    
    def count(self) -> int:
        """
        Get total number of vectors stored.
        
        Returns:
            Total point count
        """
        try:
            info = self.client.get_collection(self.collection_name)
            return info.points_count
        except Exception as e:
            logger.error(f"Failed to count points: {e}")
            return 0
    
    def get_statistics(self) -> Dict:
        """
        Get comprehensive collection statistics.
        
        Returns:
            Dictionary with statistics including HNSW index info
        """
        try:
            info = self.client.get_collection(self.collection_name)
            
            stats = {
                'collection_name': self.collection_name,
                'total_points': info.points_count,
                'vector_dimension': info.config.params.vectors.size,
                'distance_metric': info.config.params.vectors.distance.name,
                'index_type': 'HNSW',  # Qdrant uses HNSW by default
                'storage_path': str(self.storage_path),
                'local_mode': True  # No server required
            }
            
            # Calculate storage size
            storage_size = sum(
                f.stat().st_size 
                for f in self.storage_path.rglob('*') 
                if f.is_file()
            )
            stats['storage_size_mb'] = storage_size / (1024 * 1024)
            
            return stats
            
        except Exception as e:
            logger.error(f"Failed to get statistics: {e}")
            return {}
    
    def delete_collection(self) -> bool:
        """
        Delete the entire collection (for reset/cleanup).
        
        Returns:
            True if successful
        """
        try:
            self.client.delete_collection(self.collection_name)
            logger.info(f"Deleted collection: {self.collection_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete collection: {e}")
            return False
    
    def close(self):
        """Close Qdrant client and cleanup logging."""
        if hasattr(self, 'client'):
            self.client.close()
            logger.info("Vector store connection closed")
        
        # Remove log handler if it was added
        if self.log_handler_id is not None:
            logger.remove(self.log_handler_id)
            self.log_handler_id = None
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()


# ============================================================================
# UNIT TESTS - SIMPLIFIED VERSION
# ============================================================================

def test_qdrant_store():
    """Test QdrantStore functionality with simplified tests."""
    import tempfile
    import shutil
    import time
    
    print("=" * 70)
    print("QdrantStore Unit Tests")
    print("=" * 70)
    
    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    storage_path = Path(tmpdir) / "qdrant_test"
    
    try:
        # Test 1: Initialization
        print("\nTest 1: Qdrant store initialization (local mode)...")
        store = QdrantStore(
            storage_path=str(storage_path),
            collection_name="test_market_embeddings",
            enable_logging=False  # Disable logging for cleaner output
        )
        print("✓ Qdrant store initialized (no server required)")
        
        # Test 2: Create collection with HNSW
        print("\nTest 2: Collection creation with HNSW index...")
        store.initialize_collection(vector_dim=64, force_recreate=True)
        assert store.count() == 0, "Collection should be empty"
        print(f"✓ Collection created with HNSW index")
        
        # Test 3: Single insert
        print("\nTest 3: Single insertion...")
        point_id = "test_point_1"
        vector = np.random.randn(64).astype(np.float32)
        payload = {
            'symbol': 'AAPL',
            'timestamp': '2023-01-01T09:30:00'
        }
        
        success = store.insert(point_id, vector, payload)
        assert success, "Insert failed"
        time.sleep(0.1)
        assert store.count() == 1, f"Count mismatch, expected 1 got {store.count()}"
        print(f"✓ Inserted 1 vector, total count: {store.count()}")
        
        # Test 4: Retrieve by ID
        print("\nTest 4: Retrieve by ID...")
        result = store.get_by_id(point_id)
        assert result is not None, f"Point not found: {point_id}"
        assert result['payload']['symbol'] == 'AAPL', "Payload mismatch"
        print(f"✓ Retrieved point: {result['id']}")
        
        # Test 5: Batch insert
        print("\nTest 5: Batch insertion...")
        batch_records = []
        for i in range(5):
            batch_records.append((
                f"test_point_{i+2}",
                np.random.randn(64).astype(np.float32),
                {
                    'symbol': 'MSFT' if i % 2 == 0 else 'GOOGL',
                    'timestamp': f'2023-01-0{i+1}T09:30:00'
                }
            ))
        
        inserted = store.insert_batch(batch_records)
        assert inserted == 5, f"Expected 5 insertions, got {inserted}"
        time.sleep(0.1)
        total_count = store.count()
        assert total_count == 6, f"Total count mismatch, expected 6 got {total_count}"
        print(f"✓ Batch inserted 5 vectors, total count: {store.count()}")
        
        # Test 6: Similarity search (HNSW)
        print("\nTest 6: Similarity search using HNSW...")
        query_vector = np.random.randn(64).astype(np.float32)
        results = store.search(query_vector, top_k=3)
        print(f"Found {len(results)} results")
        assert len(results) == 3, f"Expected 3 results, got {len(results)}"
        print(f"✓ HNSW search found {len(results)} similar vectors")
        
        # Test 7: Filtered search
        print("\nTest 7: Filtered similarity search...")
        msft_results = store.search(
            query_vector, 
            top_k=10, 
            filter_conditions={'symbol': 'MSFT'}
        )
        print(f"Found {len(msft_results)} MSFT results")
        # We should have 3 MSFT vectors (indices 0, 2, 4)
        assert len(msft_results) == 3, f"Should find 3 MSFT vectors, got {len(msft_results)}"
        print(f"✓ Found {len(msft_results)} MSFT vectors with filter")
        
        # Test 8: Statistics
        print("\nTest 8: Get statistics...")
        stats = store.get_statistics()
        print(f"✓ Statistics: {stats['total_points']} points, {stats['vector_dimension']}D")
        
        # Test 9: Delete collection
        print("\nTest 9: Delete collection...")
        success = store.delete_collection()
        assert success, "Delete collection failed"
        print("✓ Collection deleted successfully")
        
        # Close store
        store.close()
        time.sleep(0.2)
        
        # Test 10: Context manager with fresh store
        print("\nTest 10: Context manager...")
        with QdrantStore(str(storage_path), "new_test_collection", enable_logging=False) as store2:
            store2.initialize_collection(vector_dim=64, force_recreate=True)
            # Insert 2 test vectors
            test_records = [
                ("ctx_point_1", np.random.randn(64).astype(np.float32), {'test': 'data1'}),
                ("ctx_point_2", np.random.randn(64).astype(np.float32), {'test': 'data2'})
            ]
            store2.insert_batch(test_records)
            time.sleep(0.1)
            count = store2.count()
            print(f"Context manager store has {count} points")
            assert count == 2, f"Context manager failed, expected 2 got {count}"
        print("✓ Context manager works")
        
        print("\n" + "=" * 70)
        print("✓ All tests passed!")
        print("=" * 70)
        
    except Exception as e:
        print(f"\n✗ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Cleanup
        time.sleep(0.3)
        
        # Force close any open clients
        import gc
        gc.collect()
        
        # Try to delete temp directory
        try:
            shutil.rmtree(tmpdir, ignore_errors=True)
            print(f"\nCleaned up temporary directory: {tmpdir}")
        except Exception as e:
            print(f"\nNote: Could not delete temporary directory {tmpdir}: {e}")
            print("It will be cleaned up automatically by the system.")


def quick_test():
    """Quick test function that avoids file locking issues."""
    import tempfile
    import shutil
    
    print("=" * 70)
    print("Quick QdrantStore Test")
    print("=" * 70)
    
    tmpdir = tempfile.mkdtemp()
    
    try:
        # Test basic functionality
        store = QdrantStore(str(Path(tmpdir) / "qdrant_test"), "quick_test", enable_logging=False)
        store.initialize_collection(vector_dim=32, force_recreate=True)
        
        # Insert a few vectors
        vectors = [
            ("vec1", np.random.randn(32), {'type': 'test'}),
            ("vec2", np.random.randn(32), {'type': 'test'}),
            ("vec3", np.random.randn(32), {'type': 'demo'})
        ]
        
        store.insert_batch(vectors)
        
        # Test search
        query = np.random.randn(32)
        results = store.search(query, top_k=2)
        print(f"✓ Found {len(results)} similar vectors")
        
        # Test context manager
        with QdrantStore(str(Path(tmpdir) / "qdrant_test2"), "context_test", enable_logging=False) as store2:
            store2.initialize_collection(vector_dim=32, force_recreate=True)
            store2.insert("test_point", np.random.randn(32), {'test': True})
            print(f"✓ Context manager works: {store2.count()} points")
        
        print("\n✓ All quick tests passed!")
        
    finally:
        # Cleanup using ignore_errors to handle any file locks
        shutil.rmtree(tmpdir, ignore_errors=True)
        print(f"\nCleaned up temporary directory")


if __name__ == "__main__":
    # Run the simplified test
    test_qdrant_store()